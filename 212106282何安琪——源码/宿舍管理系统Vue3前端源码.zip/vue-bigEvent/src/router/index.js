import {createRouter, createWebHistory} from 'vue-router'

// 导入组件
import LoginVue from '@/views/Login.vue'
import adminLayout from "@/views/adminLayout.vue";
import engineerLayout from "@/views/engineerLayout.vue"
import stuLayout from "@/views/stuLayout.vue"
import UserAvatar from "@/views/user/UserAvatar.vue";
import UserInfo from "@/views/user/UserInfo.vue";
import UserResetPassword from "@/views/user/UserResetPassword.vue";
import StudentManage from "@/views/students/StudentManage.vue";
import dormitoryManage from "@/views/dormitory/dormitoryManage.vue";
import visitorInfo from "@/views/visitor/visitorInfo.vue";
import propertyManage from "@/views/property/propertyManage.vue";
import StudentInfo from "@/views/students/StudentMessage.vue";
import StudentDormitory from "@/views/dormitory/StudentDormitory.vue";
import elecrecordInfo from "@/views/elec_record/elecrecordInfo.vue";
import visitorAdd from "@/views/visitor/visitorAdd.vue";
import StudentMessage from "@/views/students/StudentMessage.vue";
import MaintenanceApply from "@/views/maintenance/MaintenanceApply.vue";
import {useTokenStore} from "@/stores/token.js";
import MaintenManage from "@/views/maintenance/MaintenManage.vue";
import elecrecordManage from "@/views/elec_record/elecrecordManage.vue";

// 定义路由关系
const routes = [
    {path: '/login', component: LoginVue},

    {
        path: '/admin', component: adminLayout, redirect: '/student/manage', children: [
            {path: '/admin/avatar', component: UserAvatar},
            {path: '/admin/info', component: UserInfo},
            {path: '/admin/resetPassword', component: UserResetPassword},
            {path: '/student/manage', component: StudentManage},
            {path: '/dormitory/manage', component: dormitoryManage},
            {path: '/visitor/Info', component: visitorInfo},
            {path: '/property/manage', component: propertyManage},
        ]
    },
    {
        path: '/engineer', component: engineerLayout,redirect: '/mainten/manage',children: [
            {path: '/engineer/avatar', component: UserAvatar},
            {path: '/engineer/info', component: UserInfo},
            {path: '/engineer/resetPassword', component: UserResetPassword},
            {path: '/mainten/manage',component: MaintenManage},
            {path: '/elecrecord/manage',component: elecrecordManage},
        ]
    },
    {
        path: '/student', component: stuLayout, redirect: '/student/info', children: [
            {path: '/student/avatar', component: UserAvatar},
            {path: '/student/info', component: UserInfo},
            {path: '/student/resetPassword', component: UserResetPassword},
            {path: '/student/message', component: StudentMessage},
            {path: '/student/dormitory', component: StudentDormitory},
            {path: '/elecrecord/Info', component: elecrecordInfo},
            {path: '/visitor/Add', component: visitorAdd},
            {path: '/maintenance/apply', component: MaintenanceApply}
        ]
    },
]

// 创建路由器
const router = createRouter({
    history: createWebHistory(),
    routes: routes
})


// 导航守卫
router.beforeEach((to, from, next) => {
    if (to.path === '/login') {
        // 如果是访问登录页，则直接放行
        next();
    } else {
        const tokenStore = useTokenStore();
        // 否则判断用户是否登录，根据实际情况进行判断
        const isLoggedIn = tokenStore.token
        if (isLoggedIn) {
            // 用户已登录，允许访问目标页
            next();
        } else {
            // 用户未登录，重定向到登录页
            next('/login');
        }
    }
});
// 导出路由
export default router
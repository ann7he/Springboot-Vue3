<script setup>
import {
    Edit,
    Delete,
    Search, Check, Close
} from '@element-plus/icons-vue'
import {ref} from 'vue'

const elecRecord = ref([
    {
        "recordId": "DE222",
        "dormitoryNo": "东二222",
        "date": "2023-12-12",
        "consumption": "120",
        "cost": "42",
        "status": "未缴费"
    },
    {
        "recordId": "DE322",
        "dormitoryNo": "东二322",
        "date": "2023-12-12",
        "consumption": "80",
        "cost": "28",
        "status": "未缴费"
    },
    {
        "recordId": "DE402",
        "dormitoryNo": "东二402",
        "date": "2023-12-12",
        "consumption": "220",
        "cost": "80",
        "status": "未缴费"
    },
])
// 声明一个异步的函数
import {
    articleCategoryListService,
    articleCategoryAddService,
    articleCategoryUpdateService,
    articleCategoryDeleteService
} from "@/api/article.js";
import {ElMessage, ElMessageBox} from "element-plus";
import {visitorListService, visitorsDeleteService} from "@/api/visitor.js";
import {elecRecordListService, updatePayService} from "@/api/elecRecord.js";
import {userInfoService} from "@/api/user.js";
import {studentInfoService} from "@/api/student.js";
import {updateUseService} from "@/api/property.js";



//分页条数据模型
const pageNum = ref(1)//当前页
const total = ref(20)//总条数
const pageSize = ref(3)//每页条数

//当每页条数发生了变化，调用此函数
const onSizeChange = (size) => {
    pageSize.value = size
    elecRecordList()
}
//当前页码发生变化，调用此函数
const onCurrentChange = (num) => {
    pageNum.value = num
    elecRecordList()
}


//获取水电费清单
const elecRecordList = async () => {
    let stuInfo = await userInfoService();
    const stuId = stuInfo.data.nickname
    let result = await studentInfoService(stuId);
    // console.log(result.data.dormitoryNo)
    const dorNo = result.data.dormitoryNo

    let params = {
        pageNum: pageNum.value,
        pageSize: pageSize.value,
        dormitoryNo: dorNo? dorNo : null,
    }
    let result1 = await elecRecordListService(params);

    // 渲染视图
    total.value = result1.data.total;
    elecRecord.value = result1.data.items;
};

elecRecordList();



const updatePayState = async (row) => {
    ElMessageBox.confirm(
            '你确认支付？',
            '温馨提示',
            {
                confirmButtonText: '确定',
                cancelButtonText: '取消',
                type: 'warning',
            }
    )
            .then(async () => {
                // 调用接口
                let result = await updatePayService(row);
                ElMessage({
                    type: 'success',
                    message: '已缴费',
                })
                row.status = '已缴费'
                // 刷新列表
                await elecRecordList();
            })
            .catch(() => {
                ElMessage({
                    type: 'info',
                    message: '取消支付',
                })
            })
}
</script>
<template>
    <el-card class="page-container">
        <template #header>
            <div class="header">
                <span>水电费清单</span>
            </div>
        </template>
        <el-table :data="elecRecord" style="width: 100%">
            <el-table-column label="记录号" width="100" prop="recordId"></el-table-column>
            <el-table-column label="消费" prop="cost"></el-table-column>
            <el-table-column label="日期" prop="date"></el-table-column>
            <el-table-column label="状态" prop="status"></el-table-column>
            <el-table-column label="支付" width="100">
                <template #default="{ row }">
                    <el-button :icon="row.status==='已缴费'?Check:Close" circle plain
                               :type="row.status==='已缴费'? 'success' : 'warning'"
                               @click="row.status==='未缴费'?updatePayState(row):null"></el-button>
                </template>
            </el-table-column>
            <template #empty>
                <el-empty description="没有数据"/>
            </template>
        </el-table>

        <!-- 分页条 -->
        <el-pagination v-model:current-page="pageNum" v-model:page-size="pageSize" :page-sizes="[3, 5 ,10, 15]"
                       layout="jumper, total, sizes, prev, pager, next" background :total="total"
                       @size-change="onSizeChange"
                       @current-change="onCurrentChange" style="margin-top: 20px; justify-content: flex-end"/>

    </el-card>
</template>

<style lang="scss" scoped>
.page-container {
    min-height: 100%;
    box-sizing: border-box;

    .header {
        display: flex;
        align-items: center;
        justify-content: space-between;
    }
}
</style>
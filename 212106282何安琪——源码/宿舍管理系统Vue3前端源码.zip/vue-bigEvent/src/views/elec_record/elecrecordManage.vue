<script setup>
import {
    Delete,
    CircleCheckFilled,
    Bell
} from '@element-plus/icons-vue'

import {ref} from 'vue'
import {studentAddService, studentDeleteService, studentListService, studentUpdateService} from "@/api/student.js";

//用户搜索时选中的宿舍号
const dormitoryNo = ref('')

//用户搜索时选中的状态
const status = ref('')

//存储elecrecordList里面不重复的dormitoryNo值
const dormitoryNoList = ref([])

//文章列表数据模型
const elecRecord = ref([
    {
        "recordId": "DE222",
        "dormitoryNo": "东二222",
        "date": "2023-12-12",
        "consumption": "120",
        "cost": "42",
        "status": "未缴费"
    },
    {
        "recordId": "DE322",
        "dormitoryNo": "东二322",
        "date": "2023-12-12",
        "consumption": "80",
        "cost": "28",
        "status": "未缴费"
    },
    {
        "recordId": "DE402",
        "dormitoryNo": "东二402",
        "date": "2023-12-12",
        "consumption": "220",
        "cost": "80",
        "status": "未缴费"
    },
])


//分页条数据模型
const pageNum = ref(1)//当前页
const total = ref(20)//总条数
const pageSize = ref(3)//每页条数

//当每页条数发生了变化，调用此函数
const onSizeChange = (size) => {
    pageSize.value = size
    ElecRecordList()
}
//当前页码发生变化，调用此函数
const onCurrentChange = (num) => {
    pageNum.value = num
    ElecRecordList()
}

//获取学生列表数据
const ElecRecordList = async () => {
    let params = {
        pageNum: pageNum.value,
        pageSize: pageSize.value,
        dormitoryNo: dormitoryNo.value ? dormitoryNo.value : null,
        status: status.value ? status.value : null
    }
    let result = await elecRecordListService(params);

    // 渲染视图
    total.value = result.data.total;
    elecRecord.value = result.data.items;

    // 存储不重复的dormitoryNo值
    dormitoryNoList.value = Array.from(
            new Set(result.data.items.map((elecRecord) => elecRecord.dormitoryNo))
    );

};

ElecRecordList();
//控制添加分类弹窗
const dialogVisible = ref(false)

//添加分类数据模型
const ElecRecordModel = ref({
    recordId: '',
    dormitoryNo: '',
    date: '',
    consumption: '',
    cost: '',
    status: ''
})
//添加分类表单校验
const rules = {
    //根据宿舍号和财产自动生成
    recordId: [
        {required: true, message: '请输入记录号', trigger: 'blur'},
    ],
    dormitoryNo: [
        {required: true, message: '请输入宿舍号', trigger: 'blur'},
    ],
    date: [
        { type: 'date', required: true, message: '请选择日期', trigger: 'change' },
    ],
    consumption: [
        {required: true, message: '请输入使用电量', trigger: 'blur'},
    ],
    cost: [
        {required: true, message: '请输入费用', trigger: 'blur'},
    ],
    status: [
        { required: true, message: '请选择状态', trigger: 'change' },
    ]
}

// 调用接口，添加表单
import {ElMessage, ElMessageBox} from "element-plus";
import {propertyAddService, propertyDeleteService, propertyListService, updatePropertyService} from "@/api/property.js";
import {elecRecordAddService, elecRecordDelService, elecRecordListService} from "@/api/elecRecord.js";

const addElecRecord = async () => {
    // 调用接口
    let result = await elecRecordAddService(ElecRecordModel.value);
    ElMessage.success(result.msg ? result.msg : '添加成功')

    // 调用获取所有文章分类的函数
    await ElecRecordList();
    dialogVisible.value = false;
}
// 定义变量，控制标题的展示
const title = ref('')

// 展示编辑弹窗
const showDialog = (row) => {
    dialogVisible.value = true;
    title.value = '新增电费信息'
    // 数据拷贝
    ElecRecordModel.value.recordId = row.recordId;
    ElecRecordModel.value.dormitoryNo = row.dormitoryNo;
    ElecRecordModel.value.date = row.date;
    ElecRecordModel.value.consumption = row.consumption;
    ElecRecordModel.value.cost = row.cost;
    ElecRecordModel.value.status = row.status;
}

// 清空模型的数据
const clearData = () => {
    ElecRecordModel.value.recordId = '';
    ElecRecordModel.value.dormitoryNo = '';
    ElecRecordModel.value.date = '';
    ElecRecordModel.value.consumption = '';
    ElecRecordModel.value.cost = '';
    ElecRecordModel.value.status = '';
}

// 删除分类
const deleteElecRecord = (row) => {
    ElMessageBox.confirm(
            '你确认要删除该财产信息吗',
            '温馨提示',
            {
                confirmButtonText: '确定',
                cancelButtonText: '取消',
                type: 'warning',
            }
    )
            .then(async () => {
                // 调用接口
                let result = await elecRecordDelService(row.recordId);
                ElMessage({
                    type: 'success',
                    message: '删除成功',
                })
                // 刷新列表
                await ElecRecordList();
            })
            .catch(() => {
                ElMessage({
                    type: 'info',
                    message: '取消删除',
                })
            })
}
const sendMessage = (row) => {
    ElMessageBox.confirm(
            '确认提醒该宿舍成员缴纳电费',
            '温馨提示',
            {
                confirmButtonText: '确定',
                cancelButtonText: '取消',
                type: 'warning',
            }
    )
            .then(async () => {
                // 调用接口传说到学生界面
                // let result = await elecRecordDelService(row.recordId);
                ElMessage({
                    type: 'success',
                    message: '提醒成功',
                })
                // 刷新列表
                await ElecRecordList();
            })
            .catch(() => {
                ElMessage({
                    type: 'info',
                    message: '取消提醒',
                })
            })
}

</script>
<template>
    <el-card class="page-container">
        <template #header>
            <div class="header">
                <span>电费管理</span>
                <div class="extra">
                    <el-button type="primary" @click="dialogVisible=true;title='添加用电记录';clearData()">添加用电记录
                    </el-button>
                </div>
            </div>
        </template>
        <!-- 搜索表单 -->
        <el-form inline>
            <el-form-item label="宿舍号：">
                <el-select placeholder="请选择" v-model="dormitoryNo">
                    <el-option
                            v-for="no in dormitoryNoList"
                            :key="no"
                            :label="no"
                            :value="no">
                    </el-option>
                </el-select>
            </el-form-item>


            <el-form-item label="缴费状态：">
                <el-select placeholder="请选择" v-model="status">
                    <el-option label="未缴费" value="未缴费"></el-option>
                    <el-option label="已缴费" value="已缴费"></el-option>
                </el-select>
            </el-form-item>
            <el-form-item>
                <el-button type="primary" @click="ElecRecordList">搜索</el-button>
                <el-button @click="dormitoryNo='';status=''">重置</el-button>
            </el-form-item>
        </el-form>
        <!-- 学生列表 -->
        <el-table :data="elecRecord" style="width: 100%">
            <el-table-column label="记录号" prop="recordId"></el-table-column>
            <el-table-column label="宿舍号" prop="dormitoryNo"></el-table-column>
            <el-table-column label="日期" prop="date"></el-table-column>
            <el-table-column label="使用电量" prop="consumption"></el-table-column>
            <el-table-column label="费用" prop="cost"></el-table-column>
            <el-table-column label="缴费状态" prop="status"></el-table-column>
            <el-table-column label="操作" width="100">
                <template #default="{ row }">
                    <el-button :icon="row.status==='已缴费'?CircleCheckFilled:Bell" circle plain
                               :type="row.status==='已缴费'?'success':'warning'" @click="sendMessage(row)"></el-button>
                    <el-button :icon="Delete" circle plain type="danger" @click="deleteElecRecord(row)"></el-button>
                </template>
            </el-table-column>
            <template #empty>
                <el-empty description="没有数据"/>
            </template>
        </el-table>
        <!-- 分页条 -->
        <el-pagination v-model:current-page="pageNum" v-model:page-size="pageSize" :page-sizes="[3, 5 ,10, 15]"
                       layout="jumper, total, sizes, prev, pager, next" background :total="total"
                       @size-change="onSizeChange"
                       @current-change="onCurrentChange" style="margin-top: 20px; justify-content: flex-end"/>

        <!--        添加分类弹窗-->
        <el-dialog v-model="dialogVisible" :title="title" width="30%">
            <el-form :model="ElecRecordModel" :rules="rules" label-width="100px" style="padding-right: 30px">
                <el-form-item label="记录号" prop="recordId">
                    <el-input v-model="ElecRecordModel.recordId" minlength="1" maxlength="10"></el-input>
                </el-form-item>
                <el-form-item label="宿舍号" prop="dormitoryNo">
                    <el-input v-model="ElecRecordModel.dormitoryNo" minlength="1" maxlength="10"></el-input>
                </el-form-item>
                <el-form-item label="使用电量" prop="consumption">
                    <el-input v-model="ElecRecordModel.consumption" minlength="1" maxlength="15"></el-input>
                </el-form-item>
                <el-form-item label="费用" prop="cost">
                    <el-input v-model="ElecRecordModel.cost" minlength="1" maxlength="15"></el-input>
                </el-form-item>
                <el-form-item label="使用状态" prop="status">
                    <el-radio-group v-model="ElecRecordModel.status" size="large">
                        <el-radio-button label="未缴费" value="未缴费"/>
                    </el-radio-group>
                </el-form-item>
            </el-form>
            <template #footer>
        <span class="dialog-footer">
            <el-button @click="dialogVisible = false">取消</el-button>
            <el-button type="primary" @click="addElecRecord()"> 确认 </el-button>
        </span>
            </template>
        </el-dialog>
    </el-card>
</template>
<style lang="scss" scoped>
.page-container {
    min-height: 100%;
    box-sizing: border-box;

    .header {
        display: flex;
        align-items: center;
        justify-content: space-between;
    }
}
</style>
<script setup>
import {
    Edit,
    Delete
} from '@element-plus/icons-vue'

import {ref} from 'vue'
import {studentAddService, studentDeleteService, studentListService, studentUpdateService} from "@/api/student.js";

//用户搜索时选中的宿舍号
const dormitoryNo = ref('')

//用户搜索时选中的状态
const status = ref('')

//用户搜索时选中的财产名
const propertyName = ref('')


//存储propertyList里面不重复的dormitoryNo值
const dormitoryNoList = ref([])

//存储propertyList里面不重复的propertyName值
const propertyNameList = ref([])
//文章列表数据模型
const propertys = ref([
    {
        "propertyNo": "D1C302",
        "dormitoryNo": "东一302",
        "propertyName": "床",
        "purchaseDate": "2020-09-01",
        "status": "使用中"
    },
    {
        "propertyNo": "D1Y302",
        "dormitoryNo": "东一302",
        "propertyName": "椅子",
        "purchaseDate": "2020-09-01",
        "status": "使用中"
    },
    {
        "propertyNo": "D2C222",
        "dormitoryNo": "东二222",
        "propertyName": "床",
        "purchaseDate": "2020-09-01",
        "status": "报修中"
    },
])


//分页条数据模型
const pageNum = ref(1)//当前页
const total = ref(20)//总条数
const pageSize = ref(3)//每页条数

//当每页条数发生了变化，调用此函数
const onSizeChange = (size) => {
    pageSize.value = size
    propertyList()
}
//当前页码发生变化，调用此函数
const onCurrentChange = (num) => {
    pageNum.value = num
    propertyList()
}

//获取学生列表数据
const propertyList = async () => {
    let params = {
        pageNum: pageNum.value,
        pageSize: pageSize.value,
        dormitoryNo: dormitoryNo.value ? dormitoryNo.value : null,
        propertyName: propertyName.value ? propertyName.value : null,
        status: status.value ? status.value : null
    }
    let result = await propertyListService(params);

    // 渲染视图
    total.value = result.data.total;
    propertys.value = result.data.items;

    // 存储不重复的dormitoryNo值
    dormitoryNoList.value = Array.from(
            new Set(result.data.items.map((property) => property.dormitoryNo))
    );

    // 存储不重复的propertyName值
    propertyNameList.value = Array.from(
            new Set(result.data.items.map((property) => property.propertyName))
    );
};

propertyList();
//控制添加分类弹窗
const dialogVisible = ref(false)

//添加分类数据模型
const propertyModel = ref({
    propertyNo:'',
    dormitoryNo:'',
    propertyName:'',
    purchaseDate:'',
    status:''
})
//添加分类表单校验
const rules = {
    //根据宿舍号和财产自动生成
    propertyNo: [
        {required: true, message: '请输入财产号', trigger: 'blur'},
    ],
    dormitoryNo: [
        {required: true, message: '请输入宿舍号', trigger: 'blur'},
    ],
    propertyName: [
        {required: true, message: '请选择财产名', trigger: 'blur'},
    ],
    //默认购买时间为操作时间
    purchaseDate: [
        {required: true, message: '请选择购买时间', trigger: 'blur'},
    ],
    status: [
        {required: true, message: '请选择状态', trigger: 'blur'},
    ]
}
// 调用接口，添加表单
import {ElMessage, ElMessageBox} from "element-plus";
import {propertyAddService, propertyDeleteService, propertyListService, updatePropertyService} from "@/api/property.js";

const addProperty = async () => {
    // 调用接口
    let result = await propertyAddService(propertyModel.value);
    ElMessage.success(result.msg ? result.msg : '添加成功')

    // 调用获取所有文章分类的函数
    await propertyList();
    dialogVisible.value = false;
}
// 定义变量，控制标题的展示
const title = ref('')

// 展示编辑弹窗
const showDialog = (row) => {
    dialogVisible.value = true;
    title.value = '编辑宿舍信息'
    // 数据拷贝
    propertyModel.value.propertyNo = row.propertyNo;
    propertyModel.value.dormitoryNo = row.dormitoryNo;
    propertyModel.value.propertyName = row.propertyName;
    propertyModel.value.purchaseDate = row.purchaseDate
    propertyModel.value.status = row.status;
}

// 编辑分类
const updateProperty = async () => {
    // 调用接口
    let result = await updatePropertyService(propertyModel.value);

    ElMessage.success(result.msg ? result.msg : '修改成功')

    // 调用获取所有分类的函数
    await propertyList();
    // 隐藏弹窗
    dialogVisible.value = false;
}
// 清空模型的数据
const clearData = () => {
    propertyModel.value.propertyNo= '';
    propertyModel.value.dormitoryNo= '';
    propertyModel.value.propertyName= '';
    propertyModel.value.purchaseDate= '';
    propertyModel.value.status= '';
}

// 删除分类
const deleteProperty = (row) => {
    ElMessageBox.confirm(
            '你确认要删除该财产信息吗',
            '温馨提示',
            {
                confirmButtonText: '确定',
                cancelButtonText: '取消',
                type: 'warning',
            }
    )
            .then(async () => {
                // 调用接口
                let result = await propertyDeleteService(row.propertyNo);
                ElMessage({
                    type: 'success',
                    message: '删除成功',
                })
                // 刷新列表
                await propertyList();
            })
            .catch(() => {
                ElMessage({
                    type: 'info',
                    message: '取消删除',
                })
            })
}
</script>
<template>
    <el-card class="page-container">
        <template #header>
            <div class="header">
                <span>财产管理</span>
                <div class="extra">
                    <el-button type="primary" @click="dialogVisible=true;title='添加财产';clearData()">添加财产</el-button>
                </div>
            </div>
        </template>
        <!-- 搜索表单 -->
        <el-form inline>
            <el-form-item label="宿舍号：">
                <el-select placeholder="请选择" v-model="dormitoryNo">
                    <el-option
                            v-for="no in dormitoryNoList"
                            :key="no"
                            :label="no"
                            :value="no">
                    </el-option>
                </el-select>
            </el-form-item>

            <el-form-item label="财产名：">
                <el-select placeholder="请选择" v-model="propertyName">
                    <el-option
                            v-for="property in propertyNameList"
                            :key="property"
                            :label="property"
                            :value="property">
                    </el-option>
                </el-select>
            </el-form-item>

            <el-form-item label="财产状态：">
                <el-select placeholder="请选择" v-model="status">
                    <el-option label="使用中" value="使用中"></el-option>
                    <el-option label="报修中" value="报修中"></el-option>
                </el-select>
            </el-form-item>
            <el-form-item>
                <el-button type="primary" @click="propertyList">搜索</el-button>
                <el-button @click="dormitoryNo='';propertyName='';status=''">重置</el-button>
            </el-form-item>
        </el-form>
        <!-- 学生列表 -->
        <el-table :data="propertys" style="width: 100%">
            <el-table-column label="财产号"  prop="propertyNo"></el-table-column>
            <el-table-column label="宿舍号" prop="dormitoryNo"></el-table-column>
            <el-table-column label="财产名称" prop="propertyName"></el-table-column>
            <el-table-column label="购买时间" prop="purchaseDate"></el-table-column>
            <el-table-column label="财产状态" prop="status"></el-table-column>
            <el-table-column label="操作" width="100">
                <template #default="{ row }">
                    <el-button :icon="Edit" circle plain type="primary" @click="showDialog(row)"></el-button>
                    <el-button :icon="Delete" circle plain type="danger" @click="deleteProperty(row)"></el-button>
                </template>
            </el-table-column>
            <template #empty>
                <el-empty description="没有数据"/>
            </template>
        </el-table>
        <!-- 分页条 -->
        <el-pagination v-model:current-page="pageNum" v-model:page-size="pageSize" :page-sizes="[3, 5 ,10, 15]"
                       layout="jumper, total, sizes, prev, pager, next" background :total="total"
                       @size-change="onSizeChange"
                       @current-change="onCurrentChange" style="margin-top: 20px; justify-content: flex-end"/>

        <!--        添加分类弹窗-->
        <el-dialog v-model="dialogVisible" :title="title" width="30%">
            <el-form :model="propertyModel" :rules="rules" label-width="100px" style="padding-right: 30px">
                <el-form-item label="财产号" prop="propertyNo">
                    <el-input v-model="propertyModel.propertyNo" minlength="1"  maxlength="10"></el-input>
                </el-form-item>
                <el-form-item label="宿舍号" prop="dormitoryNo">
                    <el-input v-model="propertyModel.dormitoryNo" minlength="1"  maxlength="10"></el-input>
                </el-form-item>
                <el-form-item label="财产名称" prop="propertyName">
                    <el-input v-model="propertyModel.propertyName" minlength="1" maxlength="15"></el-input>
                </el-form-item>
                <el-form-item label="购买时间" prop="purchaseDate">
                    <el-date-picker
                            type="date"
                            placeholder="选择日期"
                            v-model="propertyModel.purchaseDate"
                    />
                </el-form-item>
                <el-form-item label="使用状态" prop="status">
                    <el-radio-group v-model="propertyModel.status" size="large">
                        <el-radio-button label="使用中" value="使用中" />
                        <el-radio-button label="报修中" value="报修中"/>
                    </el-radio-group>
                </el-form-item>
            </el-form>
            <template #footer>
        <span class="dialog-footer">
            <el-button @click="dialogVisible = false">取消</el-button>
            <el-button type="primary" @click="title==='添加财产'?addProperty():updateProperty()"> 确认 </el-button>
        </span>
            </template>
        </el-dialog>
    </el-card>
</template>
<style lang="scss" scoped>
.page-container {
    min-height: 100%;
    box-sizing: border-box;

    .header {
        display: flex;
        align-items: center;
        justify-content: space-between;
    }
}
</style>
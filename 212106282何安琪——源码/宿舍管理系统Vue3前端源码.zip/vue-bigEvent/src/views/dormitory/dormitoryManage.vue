<script setup>
import {
    Edit,
    Delete
} from '@element-plus/icons-vue'

import {ref} from 'vue'
import {studentAddService, studentDeleteService, studentListService, studentUpdateService} from "@/api/student.js";

//用户搜索时选中的楼名
const dormitoryName = ref('')

//用户搜索时选中的管理员
const administrator = ref('')


//宿舍使用状态
const status = ref('')

//存储dormitoryNoList里面不重复的major值
const administratorList = ref([])

//存储studentList里面不重复的major值
const dormitoryNameList = ref([])
//文章列表数据模型
const dormitorys = ref([
    {
        "dormitoryNo": "东一302",
        "dormitoryName": "知行楼",
        "occupancy": 3,
        "administrator": "大妈",
        "status": "使用中"
    },
    {
        "dormitoryNo": "东二421",
        "dormitoryName": "知行楼",
        "occupancy": 4,
        "administrator": "大爷",
        "status": "使用中"
    },
    {
        "dormitoryNo": "东一402",
        "dormitoryName": "知行楼",
        "occupancy": 0,
        "administrator": "大妈",
        "status": "空宿舍"
    },
])


//分页条数据模型
const pageNum = ref(1)//当前页
const total = ref(20)//总条数
const pageSize = ref(3)//每页条数

//当每页条数发生了变化，调用此函数
const onSizeChange = (size) => {
    pageSize.value = size
    dormitoryList()
}
//当前页码发生变化，调用此函数
const onCurrentChange = (num) => {
    pageNum.value = num
    dormitoryList()
}

//获取学生列表数据
const dormitoryList = async () => {
    let params = {
        pageNum: pageNum.value,
        pageSize: pageSize.value,
        dormitoryName: dormitoryName.value ? dormitoryName.value : null,
        administrator: administrator.value ? administrator.value : null,
        status: status.value ? status.value : null
    }
    let result = await dormitoryListService(params);

    // 渲染视图
    total.value = result.data.total;
    dormitorys.value = result.data.items;

    // 存储不重复的administrator值
    administratorList.value = Array.from(
            new Set(result.data.items.map((dormitory) => dormitory.administrator))
    );

    // 存储不重复的majordormitoryName值
    dormitoryNameList.value = Array.from(
            new Set(result.data.items.map((dormitory) => dormitory.dormitoryName))
    );
};

dormitoryList();
//控制添加分类弹窗
const dialogVisible = ref(false)

//添加分类数据模型
const dormitoryModel = ref({
    dormitoryNo:'',
    dormitoryName:'',
    occupancy:'',
    administrator:'',
    status:''
})
//添加分类表单校验
const rules = {
    dormitoryNo: [
        {required: true, message: '请输入宿舍号', trigger: 'blur'},
    ],
    dormitoryName: [
        {required: true, message: '请输入楼名', trigger: 'blur'},
    ],
    occupancy: [
        {required: true, message: '请输入人数', trigger: 'blur'},
    ],
    administrator: [
        {required: true, message: '请输入管理员', trigger: 'blur'},
    ],
    status: [
        {required: true, message: '请选择状态', trigger: 'blur'},
    ]
}
// 调用接口，添加表单
import {ElMessage, ElMessageBox} from "element-plus";
import {
    dormitoryAddService,
    dormitoryDeleteService,
    dormitoryListService,
    updateDormitoryService
} from "@/api/dormitory.js";

const addDormitory = async () => {
    // 调用接口
    let result = await dormitoryAddService(dormitoryModel.value);
    ElMessage.success(result.msg ? result.msg : '添加成功')

    // 调用获取所有文章分类的函数
    await dormitoryList();
    dialogVisible.value = false;
}
// 定义变量，控制标题的展示
const title = ref('')

// 展示编辑弹窗
const showDialog = (row) => {
    dialogVisible.value = true;
    title.value = '编辑宿舍信息'
    // 数据拷贝
    dormitoryModel.value.dormitoryNo = row.dormitoryNo;
    dormitoryModel.value.dormitoryName = row.dormitoryName;
    dormitoryModel.value.administrator = row.administrator;
    dormitoryModel.value.occupancy = row.occupancy;
    dormitoryModel.value.status = row.status;

    // 扩展id属性，将来需要传递给后台，完成分类的修改
    // studentModel.value.id = row.id
    // 设置为禁止输入
}

// 编辑分类
const updateDormitory = async () => {
    // 调用接口
    let result = await updateDormitoryService(dormitoryModel.value);

    ElMessage.success(result.msg ? result.msg : '修改成功')

    // 调用获取所有分类的函数
    await dormitoryList();
    // 隐藏弹窗
    dialogVisible.value = false;
}
// 清空模型的数据
const clearData = () => {
    dormitoryModel.value.dormitoryNo= '';
    dormitoryModel.value.dormitoryName= '';
    dormitoryModel.value.occupancy= '';
    dormitoryModel.value.administrator= '';
    dormitoryModel.value.status= '';
}

// 删除分类
const deleteDormitory = (row) => {
    ElMessageBox.confirm(
            '你确认要删除该宿舍信息吗',
            '温馨提示',
            {
                confirmButtonText: '确定',
                cancelButtonText: '取消',
                type: 'warning',
            }
    )
            .then(async () => {
                // 调用接口
                let result = await dormitoryDeleteService(row.dormitoryNo);
                ElMessage({
                    type: 'success',
                    message: '删除成功',
                })
                // 刷新列表
                await dormitoryList();
            })
            .catch(() => {
                ElMessage({
                    type: 'info',
                    message: '取消删除',
                })
            })
}
</script>
<template>
    <el-card class="page-container">
        <template #header>
            <div class="header">
                <span>学生管理</span>
                <div class="extra">
                    <el-button type="primary" @click="dialogVisible=true;title='添加宿舍';clearData()">添加宿舍</el-button>
                </div>
            </div>
        </template>
        <!-- 搜索表单 -->
        <el-form inline>
            <el-form-item label="楼名：">
                <el-select placeholder="请选择" v-model="dormitoryName">
                    <el-option
                            v-for="name in dormitoryNameList"
                            :key="name"
                            :label="name"
                            :value="name">
                    </el-option>
                </el-select>
            </el-form-item>

            <el-form-item label="管理员：">
                <el-select placeholder="请选择" v-model="administrator">
                    <el-option
                            v-for="admin in administratorList"
                            :key="admin"
                            :label="admin"
                            :value="admin">
                    </el-option>
                </el-select>
            </el-form-item>

            <el-form-item label="使用状态：">
                <el-select placeholder="请选择" v-model="status">
                    <el-option label="空宿舍" value="空宿舍"></el-option>
                    <el-option label="使用中" value="使用中"></el-option>
                </el-select>
            </el-form-item>
            <el-form-item>
                <el-button type="primary" @click="dormitoryList">搜索</el-button>
                <el-button @click="dormitoryName='';administrator='';status=''">重置</el-button>
            </el-form-item>
        </el-form>
        <!-- 学生列表 -->
        <el-table :data="dormitorys" style="width: 100%">
            <el-table-column label="宿舍号"  prop="dormitoryNo"></el-table-column>
            <el-table-column label="楼名" prop="dormitoryName"></el-table-column>
            <el-table-column label="宿舍人数" prop="occupancy"></el-table-column>
            <el-table-column label="管理员" prop="administrator"></el-table-column>
            <el-table-column label="使用状态" prop="status"></el-table-column>
            <el-table-column label="操作" width="100">
                <template #default="{ row }">
                    <el-button :icon="Edit" circle plain type="primary" @click="showDialog(row)"></el-button>
                    <el-button :icon="Delete" circle plain type="danger" @click="deleteDormitory(row)"></el-button>
                </template>
            </el-table-column>
            <template #empty>
                <el-empty description="没有数据"/>
            </template>
        </el-table>
        <!-- 分页条 -->
        <el-pagination v-model:current-page="pageNum" v-model:page-size="pageSize" :page-sizes="[3, 5 ,10, 15]"
                       layout="jumper, total, sizes, prev, pager, next" background :total="total"
                       @size-change="onSizeChange"
                       @current-change="onCurrentChange" style="margin-top: 20px; justify-content: flex-end"/>

        <!--        添加分类弹窗-->
        <el-dialog v-model="dialogVisible" :title="title" width="30%">
            <el-form :model="dormitoryModel" :rules="rules" label-width="100px" style="padding-right: 30px">
                <el-form-item label="宿舍号" prop="dormitoryNo">
                    <el-input v-model="dormitoryModel.dormitoryNo" minlength="1"  maxlength="10"></el-input>
                </el-form-item>
                <el-form-item label="楼名" prop="dormitoryName">
                    <el-input v-model="dormitoryModel.dormitoryName" minlength="1" maxlength="15"></el-input>
                </el-form-item>
                <el-form-item label="宿舍人数" prop="occupancy">
                    <el-input v-model="dormitoryModel.occupancy" minlength="1" maxlength="15"></el-input>
                </el-form-item>
                <el-form-item label="管理员" prop="administrator">
                    <el-input v-model="dormitoryModel.administrator" minlength="1" maxlength="15"></el-input>
                </el-form-item>
                <el-form-item label="使用状态" prop="status">
                    <el-radio-group v-model="dormitoryModel.status" size="large">
                        <el-radio-button label="空宿舍" value="空宿舍" />
                        <el-radio-button label="使用中" value="使用中"/>
                    </el-radio-group>
                </el-form-item>
            </el-form>
            <template #footer>
        <span class="dialog-footer">
            <el-button @click="dialogVisible = false">取消</el-button>
            <el-button type="primary" @click="title==='添加宿舍'?addDormitory():updateDormitory()"> 确认 </el-button>
        </span>
            </template>
        </el-dialog>
    </el-card>
</template>
<style lang="scss" scoped>
.page-container {
    min-height: 100%;
    box-sizing: border-box;

    .header {
        display: flex;
        align-items: center;
        justify-content: space-between;
    }
}
</style>
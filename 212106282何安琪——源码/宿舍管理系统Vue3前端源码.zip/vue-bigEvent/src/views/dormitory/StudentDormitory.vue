<script setup>
import {
    Edit,
    Delete
} from '@element-plus/icons-vue'
import { ref } from 'vue'
import {
    articleCategoryListService,
} from "@/api/article.js";
import {studentInfoService, studentListService} from "@/api/student.js";
import {userInfoService} from "@/api/user.js";
import {dormitoryInfoService, dormitoryListService} from "@/api/dormitory.js";

const dormitory = ref({
    dormitoryNo: "东一302",
    dormitoryName: "知行楼",
    occupancy: 0,
    administrator: "大妈",
    status: "空宿舍"
});

const dormitoryInfo = async () => {
    let stuInfo = await userInfoService();
    const stuId = stuInfo.data.nickname
    let result = await studentInfoService(stuId);
    console.log(result.data.dormitoryNo)
    const dorNo = result.data.dormitoryNo
    let result1 = await dormitoryInfoService(dorNo);
    // console.log(result1)
    dormitory.value = result1.data;
}

dormitoryInfo();

const tableData = ref([
    {
        sno: "212106181",
        sname: "翠花",
        major: "软件工程",
        dormitoryNo: "东三321",
        moveInDate: "2023-11-02"
    },
    {
        sno: "212106282",
        sname: "何安琪",
        major: "软件工程",
        dormitoryNo: "东三321",
        moveInDate: "2023-11-02"
    },
    {
        sno: "212106320",
        sname: "小美",
        major: "计算机科学与技术",
        dormitoryNo: "东三321",
        moveInDate: "2023-11-02"
    }
])

//分页条数据模型
const pageNum = ref(1)//当前页
const total = ref(20)//总条数
const pageSize = ref(4)//每页条数

// //当每页条数发生了变化，调用此函数
// const onSizeChange = (size) => {
//     pageSize.value = size
//     rootmateList()
// }
// //当前页码发生变化，调用此函数
// const onCurrentChange = (num) => {
//     pageNum.value = num
//     rootmateList()
// }


//获取宿舍信息
const rootmateList = async () => {
    let stuInfo = await userInfoService();
    const stuId = stuInfo.data.nickname
    let result = await studentInfoService(stuId);
    // console.log(result.data.dormitoryNo)
    const dorNo = result.data.dormitoryNo
    console.log(dorNo)
    let params = {
        pageNum: pageNum.value,
        pageSize: pageSize.value,
        dormitoryNo: dorNo ? dorNo : null,
    }
    let result1 = await studentListService(params);
    // 渲染视图
    console.log(result1.data)
    // total.value = result1.data.total;
    tableData.value = result1.data.items;
}

rootmateList();

</script>

<template>
    <el-card class="page-container">
        <el-descriptions
                title="宿舍信息"
                direction="vertical"
                :column="3"
                :size="'large'"
                border
        >
            <el-descriptions-item label="楼名">{{dormitory.dormitoryName}}</el-descriptions-item>
            <el-descriptions-item label="宿舍号">{{dormitory.dormitoryNo}}</el-descriptions-item>
            <el-descriptions-item label="宿舍管理员">{{dormitory.administrator}}</el-descriptions-item>
            <el-descriptions-item label="宿舍人数">
                <el-tag size="small">{{dormitory.occupancy}}</el-tag>
            </el-descriptions-item>
        </el-descriptions>

        <br>
        <el-descriptions
                title=" 宿舍成员"
        />
        <el-table :data="tableData" border style="width: 100%">
            <el-table-column prop="sname" label="名字" width="290" />
            <el-table-column prop="major" label="专业" width="290" />
            <el-table-column prop="moveInDate" label="入住时间" />
        </el-table>

<!--        &lt;!&ndash; 分页条 &ndash;&gt;-->
<!--        <el-pagination v-model:current-page="pageNum" v-model:page-size="pageSize" :page-sizes="[3, 5 ,10, 15]"-->
<!--                       layout="jumper, total, sizes, prev, pager, next" background :total="total"-->
<!--                       @size-change="onSizeChange"-->
<!--                       @current-change="onCurrentChange" style="margin-top: 20px; justify-content: flex-end"/>-->

    </el-card>
</template>

<style lang="scss" scoped>
.page-container {
    min-height: 100%;
    box-sizing: border-box;

    .header {
        display: flex;
        align-items: center;
        justify-content: space-between;
    }
}
</style>

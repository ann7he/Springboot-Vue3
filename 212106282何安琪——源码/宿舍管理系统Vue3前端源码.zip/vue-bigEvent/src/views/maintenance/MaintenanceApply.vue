<script setup>
import {
    Edit,
    Delete, Check, Close
} from '@element-plus/icons-vue'
import {ref} from 'vue'

const propertys = ref([
    {
        "propertyNo": "D1C302",
        "dormitoryNo": "东一302",
        "propertyName": "床",
        "purchaseDate": "2020-09-01",
        "status": "使用中"
    },
    {
        "propertyNo": "D1Y302",
        "dormitoryNo": "东一302",
        "propertyName": "椅子",
        "purchaseDate": "2020-09-01",
        "status": "使用中"
    },
    {
        "propertyNo": "D2C222",
        "dormitoryNo": "东二222",
        "propertyName": "床",
        "purchaseDate": "2020-09-01",
        "status": "报修中"
    },
])
// 声明一个异步的函数
import {
    articleCategoryListService,
    articleCategoryAddService,
    articleCategoryUpdateService,
    articleCategoryDeleteService
} from "@/api/article.js";
import {propertyListService, updateUseService} from "@/api/property.js";
import {userInfoService} from "@/api/user.js";
import {studentInfoService} from "@/api/student.js";
import {ElMessage, ElMessageBox} from "element-plus";
import {updateMaintenanceService} from "@/api/maintenance.js";
//分页条数据模型
const pageNum = ref(1)//当前页
const total = ref(20)//总条数
const pageSize = ref(3)//每页条数

//当每页条数发生了变化，调用此函数
const onSizeChange = (size) => {
    pageSize.value = size
    propertyList()
}
//当前页码发生变化，调用此函数
const onCurrentChange = (num) => {
    pageNum.value = num
    propertyList()
}
const propertyList = async () => {
    let stuInfo = await userInfoService();
    const stuId = stuInfo.data.nickname
    let result = await studentInfoService(stuId);
    // console.log(result.data.dormitoryNo)
    const dorNo = result.data.dormitoryNo
    let params = {
        pageNum: pageNum.value,
        pageSize: pageSize.value,
        dormitoryNo: dorNo ? dorNo : null
    }
    let result1 = await propertyListService(params);

    // 渲染视图
    total.value = result1.data.total;
    propertys.value = result1.data.items;

};
propertyList();

const updateUseState = async (row) => {
    ElMessageBox.confirm(
            '你确认申请报修？',
            '温馨提示',
            {
                confirmButtonText: '确定',
                cancelButtonText: '取消',
                type: 'warning',
            }
    )
            .then(async () => {
                // 调用接口
                let result = await updateUseService(row);
                ElMessage({
                    type: 'success',
                    message: '申请成功',
                })
                row.status = '已报修'
                // 刷新列表
                await propertyList();
            })
            .catch(() => {
                ElMessage({
                    type: 'info',
                    message: '取消报修',
                })
            })
}

</script>
<template>
    <el-card class="page-container">
        <template #header>
            <div class="header">
                <span>宿舍财产</span>
                <div class="extra">
                    <el-button type="primary">联系后勤部门
                    </el-button>
                </div>
            </div>
        </template>
        <el-table :data="propertys" style="width: 100%">
            <el-table-column label="财产号" width="100" prop="propertyNo"></el-table-column>
            <el-table-column label="财产名" prop="propertyName"></el-table-column>
            <el-table-column label="状态" prop="status"></el-table-column>
            <el-table-column label="申请报修" width="100">
                <template #default="{ row }">
                    <el-button :icon="row.status==='使用中'?Check:Close" circle plain
                               :type="row.status==='使用中'? 'success' : 'warning'"
                               @click="row.status==='使用中'?updateUseState(row):null"></el-button>
                </template>
            </el-table-column>
            <template #empty>
                <el-empty description="没有数据"/>
            </template>
        </el-table>

        <!-- 分页条 -->
        <el-pagination v-model:current-page="pageNum" v-model:page-size="pageSize" :page-sizes="[3, 5 ,10, 15]"
                       layout="jumper, total, sizes, prev, pager, next" background :total="total"
                       @size-change="onSizeChange"
                       @current-change="onCurrentChange" style="margin-top: 20px; justify-content: flex-end"/>

    </el-card>
</template>

<style lang="scss" scoped>
.page-container {
    min-height: 100%;
    box-sizing: border-box;

    .header {
        display: flex;
        align-items: center;
        justify-content: space-between;
    }
}
</style>
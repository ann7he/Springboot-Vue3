<script setup>
import {
    More,
    Delete,
    Close,
    Check
} from '@element-plus/icons-vue'

import {ref} from 'vue'
import {studentAddService, studentDeleteService, studentListService, studentUpdateService} from "@/api/student.js";

//用户搜索时选中的宿舍号
const dormitoryNo = ref('')


//宿舍使用状态
const status = ref('')

//存储maintenanceList里面不重复的dormitoryNo值
const dormitoryNoList = ref([])

//文章列表数据模型
const maintenance = ref([
    {
        "maintenId": "D2C402",
        "dormitoryNo": "东二402",
        "propertyNo": "D2C402",
        "maintenTime": "2023-12-11T22:28:59",
        "reason": "床坏掉了！",
        "status": "报修中"
    },
    {
        "maintenId": "D2C402",
        "dormitoryNo": "东二402",
        "propertyNo": "D2C402",
        "maintenTime": "2023-12-11T22:28:59",
        "reason": "床坏掉了！",
        "status": "报修中"
    },
    {
        "maintenId": "D2C402",
        "dormitoryNo": "东二402",
        "propertyNo": "D2C402",
        "maintenTime": "2023-12-11T22:28:59",
        "reason": "床坏掉了！",
        "status": "报修中"
    },
])


//分页条数据模型
const pageNum = ref(1)//当前页
const total = ref(20)//总条数
const pageSize = ref(3)//每页条数

//当每页条数发生了变化，调用此函数
const onSizeChange = (size) => {
    pageSize.value = size
    maintenanceList()
}
//当前页码发生变化，调用此函数
const onCurrentChange = (num) => {
    pageNum.value = num
    maintenanceList()
}

//获取学生列表数据
const maintenanceList = async () => {
    let params = {
        pageNum: pageNum.value,
        pageSize: pageSize.value,
        dormitoryNo: dormitoryNo.value ? dormitoryNo.value : null,
        status: status.value ? status.value : null
    }
    let result = await maintenanceListService(params);

    // 渲染视图
    total.value = result.data.total;
    maintenance.value = result.data.items;

    // 存储不重复的administrator值
    dormitoryNoList.value = Array.from(
            new Set(result.data.items.map((maintenance) => maintenance.dormitoryNo))
    );

};

maintenanceList();


//控制添加分类弹窗
const dialogVisible = ref(false)



import {ElMessage, ElMessageBox} from "element-plus";
import {
    dormitoryDeleteService,
    updateDormitoryService
} from "@/api/dormitory.js";
import {maintenanceDeleteService, maintenanceListService, updateMaintenanceService} from "@/api/maintenance.js";


// 定义变量，控制标题的展示
const title = ref('')


// 编辑分类
const updateMainState = async (row) => {
    ElMessageBox.confirm(
            '你确认已报修？',
            '温馨提示',
            {
                confirmButtonText: '确定',
                cancelButtonText: '取消',
                type: 'warning',
            }
    )
            .then(async () => {
                // 调用接口
                let result = await updateMaintenanceService(row);
                ElMessage({
                    type: 'success',
                    message: '完成报修',
                })
                row.status = '已报修'
                // 刷新列表
                await maintenanceList();
            })
            .catch(() => {
                ElMessage({
                    type: 'info',
                    message: '取消报修',
                })
            })
}



// 删除分类
const deleteMaintenance = (row) => {
    ElMessageBox.confirm(
            '你确认要删除该宿舍信息吗',
            '温馨提示',
            {
                confirmButtonText: '确定',
                cancelButtonText: '取消',
                type: 'warning',
            }
    )
            .then(async () => {
                // 调用接口
                let result = await maintenanceDeleteService(row.maintenId);
                ElMessage({
                    type: 'success',
                    message: '删除成功',
                })
                // 刷新列表
                await maintenanceList();
            })
            .catch(() => {
                ElMessage({
                    type: 'info',
                    message: '取消删除',
                })
            })
}
</script>
<template>
    <el-card class="page-container">
        <template #header>
            <div class="header">
                <span>维修管理</span>
            </div>
        </template>
        <!-- 搜索表单 -->
        <el-form inline>
            <el-form-item label="宿舍号：">
                <el-select placeholder="请选择" v-model="dormitoryNo">
                    <el-option
                            v-for="no in dormitoryNoList"
                            :key="no"
                            :label="no"
                            :value="no">
                    </el-option>
                </el-select>
            </el-form-item>

            <el-form-item label="报修状态：">
                <el-select placeholder="请选择" v-model="status">
                    <el-option label="报修中" value="报修中"></el-option>
                    <el-option label="已报修" value="已报修"></el-option>
                </el-select>
            </el-form-item>
            <el-form-item>
                <el-button type="primary" @click="maintenanceList">搜索</el-button>
                <el-button @click="dormitoryNo='';status=''">重置</el-button>
            </el-form-item>
        </el-form>
        <!--维修列表 -->
        <el-table :data="maintenance" style="width: 100%">
            <el-table-column label="维修ID" prop="maintenId"></el-table-column>
            <el-table-column label="宿舍号" prop="dormitoryNo"></el-table-column>
            <el-table-column label="财产号" prop="propertyNo"></el-table-column>
            <el-table-column label="维修时间" prop="maintenTime"></el-table-column>
            <el-table-column label="报修状态" prop="status"></el-table-column>
            <el-table-column label="操作" width="150">
                <template #default="{ row }">
                    <el-popover
                            placement="top-start"
                            title="损坏原因"
                            :width="200"
                            trigger="hover"
                            :content= row.reason
                    >
                        <template #reference>
                            <el-button :icon="More" circle plain type="info"></el-button>
                        </template>
                    </el-popover>
                    <el-button :icon="row.status==='已报修'?Check:Close" circle plain
                               :type="row.status==='已报修'? 'success' : 'warning'"
                               @click="row.status==='报修中'?updateMainState(row):null"></el-button>
                    <el-button :icon="Delete" circle plain type="danger" @click="deleteMaintenance(row)"></el-button>
                </template>
            </el-table-column>
            <template #empty>
                <el-empty description="没有数据"/>
            </template>
        </el-table>
        <!-- 分页条 -->
        <el-pagination v-model:current-page="pageNum" v-model:page-size="pageSize" :page-sizes="[3, 5 ,10, 15]"
                       layout="jumper, total, sizes, prev, pager, next" background :total="total"
                       @size-change="onSizeChange"
                       @current-change="onCurrentChange" style="margin-top: 20px; justify-content: flex-end"/>


    </el-card>
</template>
<style lang="scss" scoped>
.page-container {
    min-height: 100%;
    box-sizing: border-box;

    .header {
        display: flex;
        align-items: center;
        justify-content: space-between;
    }
}
</style>
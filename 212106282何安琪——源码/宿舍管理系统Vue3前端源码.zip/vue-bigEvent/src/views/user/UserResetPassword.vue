<script setup>
import { ref } from 'vue'

const password = ref({
    old_pwd: "2345678",
    new_pwd: "123456",
    re_pwd: "123456"
})

const rules = {
    old_pwd: [
        { required: true, message: '请输入原密码', trigger: 'blur' },
        { type: 'password', trigger: 'blur' }
    ],
    new_pwd: [
        { required: true, message: '请输入新密码', trigger: 'blur' },
        { type: 'password', trigger: 'blur' }
    ],
    re_pwd: [
        { required: true, message: '请再次输入新密码', trigger: 'blur' },
        { type: 'password', trigger: 'blur' }
    ]
}

const tokenStore = useTokenStore();
import { updateUserInfoService, updateUserPasswordService } from "@/api/user.js";
import { ElMessage } from "element-plus";
import { useTokenStore } from "@/stores/token.js";

// 修改个人信息
const updateUserPassword = async (password) => {
    // 调用接口
    let result = await updateUserPasswordService(password, tokenStore.token)
    ElMessage.success(result.msg ? result.msg : '修改成功');
}

</script>
<template>
    <el-card class="page-container">
        <template #header>
            <div class="header">
                <span>基本资料</span>
            </div>
        </template>
        <el-row>
            <el-col :span="12">
                <el-form :model="password" :rules="rules" label-width="100px" size="large">
                    <el-form-item label="旧密码">
                        <el-input v-model="password.old_pwd"></el-input>
                    </el-form-item>
                    <el-form-item label="新密码" prop="nickname">
                        <el-input v-model="password.new_pwd"></el-input>
                    </el-form-item>
                    <el-form-item label="再次输入" prop="email">
                        <el-input v-model="password.re_pwd"></el-input>
                    </el-form-item>
                    <el-form-item>
                        <el-button type="primary" @click="updateUserPassword(password)">提交修改</el-button>
                    </el-form-item>
                </el-form>
            </el-col>
        </el-row>
    </el-card>
</template>

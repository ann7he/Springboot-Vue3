<script setup>
import {
    Edit,
    Delete,
    Search
} from '@element-plus/icons-vue'
import {ref} from 'vue'
//查询的学生学号
const sno = ref()

const visitors = ref([
    {
        "recordId": "922001",
        "sno": "1357435",
        "visitorName": "李大七",
        "visitTime": "2023-12-09T19:39:18"
    },
    {
        "recordId": "922002",
        "sno": "1357435",
        "visitorName": "李大七",
        "visitTime": "2023-12-18T15:00:22"
    },
    {
        "recordId": "922003",
        "sno": "1357435",
        "visitorName": "李大七",
        "visitTime": "2023-12-18T15:00:27"
    }
])
// 声明一个异步的函数
import {
    articleCategoryListService,
    articleCategoryAddService,
    articleCategoryUpdateService,
    articleCategoryDeleteService
} from "@/api/article.js";
import {ElMessage, ElMessageBox} from "element-plus";
import {visitorListService, visitorsDeleteService} from "@/api/visitor.js";

const visitorList = async (value) => {
    let result = await visitorListService(value);
    visitors.value = result.data;
}
visitorList();

// 查询访客列表
const searchVisitor = async () => {
    await visitorList(sno.value);
}
// 删除分类
const deleteVisitor = (row) => {
    ElMessageBox.confirm(
            '你确认要删除该访客信息吗',
            '温馨提示',
            {
                confirmButtonText: '确定',
                cancelButtonText: '取消',
                type: 'warning',
            }
    )
            .then(async () => {
                // 调用接口
                let result = await visitorsDeleteService(row.recordId);
                ElMessage({
                    type: 'success',
                    message: '删除成功',
                })
                // 刷新列表
                await searchVisitor();
            })
            .catch(() => {
                ElMessage({
                    type: 'info',
                    message: '取消删除',
                })
            })
}

</script>
<template>
    <el-card class="page-container">
        <template #header>
            <div class="header">
                <span>查询访客列表</span>
                <div class="extra">
                    <el-form inline>
                        <el-form-item>
                            <el-input v-model="sno" placeholder="请输入学生学号" ></el-input>
                        </el-form-item>
                        <el-form-item>
                            <el-button :icon="Search" circle @click="searchVisitor"/>
                        </el-form-item>
                    </el-form>
                </div>
            </div>
        </template>
        <el-table :data="visitors" style="width: 100%">
            <el-table-column label="记录号" width="100" prop="recordId"></el-table-column>
            <el-table-column label="学号" prop="sno"></el-table-column>
            <el-table-column label="访客信息" prop="visitorName"></el-table-column>
            <el-table-column label="访客时间" prop="visitTime"></el-table-column>
            <el-table-column label="操作" width="100">
                <template #default="{ row }">
                    <el-button :icon="Delete" circle plain type="danger" @click="deleteVisitor(row)"></el-button>
                </template>
            </el-table-column>
            <template #empty>
                <el-empty description="没有数据"/>
            </template>
        </el-table>
    </el-card>
</template>

<style lang="scss" scoped>
.page-container {
    min-height: 100%;
    box-sizing: border-box;

    .header {
        display: flex;
        align-items: center;
        justify-content: space-between;
    }
}
</style>
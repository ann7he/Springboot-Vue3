<script setup>
import {
    Edit,
    Delete,
    Search
} from '@element-plus/icons-vue'
import {ref} from 'vue'

const visitors = ref([
    {
        "recordId": "922001",
        "sno": "1357435",
        "visitorName": "李大七",
        "visitTime": "2023-12-09T19:39:18"
    },
    {
        "recordId": "922002",
        "sno": "1357435",
        "visitorName": "李大七",
        "visitTime": "2023-12-18T15:00:22"
    },
    {
        "recordId": "922003",
        "sno": "1357435",
        "visitorName": "李大七",
        "visitTime": "2023-12-18T15:00:27"
    }
])
// 声明一个异步的函数
import {
    articleCategoryListService,
    articleCategoryAddService,
    articleCategoryUpdateService,
    articleCategoryDeleteService
} from "@/api/article.js";
import {ElMessage, ElMessageBox} from "element-plus";
import {visitorAddService, visitorListService, visitorsDeleteService} from "@/api/visitor.js";
import {userInfoService} from "@/api/user.js";
import {studentInfoService} from "@/api/student.js";
import {dormitoryAddService} from "@/api/dormitory.js";

const MyVisitor = async () => {
    let stuInfo = await userInfoService();
    const stuId = stuInfo.data.nickname
    // console.log(stuId)
    let result = await visitorListService(stuId);
    console.log(result)
    visitors.value = result.data
}
MyVisitor();

//控制添加分类弹窗
const dialogVisible = ref(false)

//添加分类数据模型
const visitorModel = ref({
    recordId:"",
    sno:"",
    sname:"",
    visitorName:"",
    visitTime:""
})
//添加分类表单校验
const rules = {
    recordId: [
        {required: true, message: '请输入记录号', trigger: 'blur'},
    ],
    sno: [
        {required: true, message: '请输入学号', trigger: 'blur'},
    ],
    sname: [
        {required: true, message: '请输入学生姓名', trigger: 'blur'},
    ],
    visitorName: [
        {required: true, message: '请输入访客姓名', trigger: 'blur'},
    ]
}
// 定义变量，控制标题的展示
const title = ref('')

const addVisitor = async () => {
    // 调用接口
    let result = await visitorAddService(visitorModel.value);
    ElMessage.success(result.msg ? result.msg : '添加成功')

    // 调用获取所有文章分类的函数
    await MyVisitor();
    dialogVisible.value = false;
}


// 展示编辑弹窗

// 清空模型的数据
const clearData = () => {
    visitorModel.value.recordId= '';
    visitorModel.value.sno= '';
    visitorModel.value.sname= '';
    visitorModel.value.visitorName= '';
    visitorModel.value.visitTime= '';
}

</script>
<template>
    <el-card class="page-container">

        <template #header>
            <div class="header">
                <span>访客列表</span>
                <div class="extra">
                    <el-button type="primary" @click="dialogVisible=true;clearData()">访客登记</el-button>
                </div>
            </div>
        </template>
        <el-table :data="visitors" style="width: 100%">
            <el-table-column label="记录号" width="100" prop="recordId"></el-table-column>
            <el-table-column label="学号" prop="sno"></el-table-column>
            <el-table-column label="访客信息" prop="visitorName"></el-table-column>
            <el-table-column label="访客时间" prop="visitTime"></el-table-column>
            <template #empty>
                <el-empty description="没有数据"/>
            </template>
        </el-table>
        <!--        添加分类弹窗-->
        <el-dialog v-model="dialogVisible" :title="title" width="30%">
            <el-form :model="visitorModel" :rules="rules" label-width="100px" style="padding-right: 30px">
                <el-form-item label="记录号" prop="recordId">
                    <el-input v-model="visitorModel.recordId" minlength="1"  maxlength="10"></el-input>
                </el-form-item>
                <el-form-item label="学号" prop="sno">
                    <el-input v-model="visitorModel.sno" minlength="1" maxlength="15"></el-input>
                </el-form-item>
                <el-form-item label="学生姓名" prop="sname">
                    <el-input v-model="visitorModel.sname" minlength="1" maxlength="15"></el-input>
                </el-form-item>
                <el-form-item label="访客姓名" prop="visitorName">
                    <el-input v-model="visitorModel.visitorName" minlength="1" maxlength="15"></el-input>
                </el-form-item>
            </el-form>
            <template #footer>
        <span class="dialog-footer">
            <el-button @click="dialogVisible = false">取消</el-button>
            <el-button type="primary" @click="addVisitor()"> 确认 </el-button>
        </span>
            </template>
        </el-dialog>
    </el-card>
</template>

<style lang="scss" scoped>
.page-container {
    min-height: 100%;
    box-sizing: border-box;

    .header {
        display: flex;
        align-items: center;
        justify-content: space-between;
    }
}
</style>
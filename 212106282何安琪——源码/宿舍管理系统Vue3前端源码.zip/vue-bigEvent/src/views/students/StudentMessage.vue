<script setup>
import {
    Edit,
    Delete
} from '@element-plus/icons-vue'
import { ref } from 'vue'
import {
    articleCategoryListService,
} from "@/api/article.js";
import { studentInfoService } from "@/api/student.js";
import {userInfoService} from "@/api/user.js";

const student = ref({
    sno: '212106282',
    sname: '',
    major: '',
    dormitoryNo: '',
    moveInDate: ''
});

const studentInfo = async () => {
    let stuInfo = await userInfoService();
    const stuId = stuInfo.data.nickname
    let result = await studentInfoService(stuId);
    // console.log(result)
    student.value.sno = result.data.sno;
    student.value.sname = result.data.sname;
    student.value.major = result.data.major;
    student.value.dormitoryNo = result.data.dormitoryNo;
    student.value.moveInDate = result.data.moveInDate;
}

studentInfo(student.value.sno);

</script>

<template>
    <el-card class="page-container">
        <el-descriptions
                title="我的信息"
                direction="vertical"
                :column="2"
                :size="'large'"
                border
        >
            <el-descriptions-item label="姓名">{{student.sname}}</el-descriptions-item>
            <el-descriptions-item label="学号">{{student.sno}}</el-descriptions-item>
            <el-descriptions-item label="专业">{{student.major}}</el-descriptions-item>
            <el-descriptions-item label="所在宿舍">
                <el-tag size="small">{{student.dormitoryNo}}</el-tag>
            </el-descriptions-item>
            <el-descriptions-item label="入住时间">{{student.moveInDate}}</el-descriptions-item>
        </el-descriptions>
    </el-card>
</template>

<style lang="scss" scoped>
.page-container {
    min-height: 100%;
    box-sizing: border-box;

    .header {
        display: flex;
        align-items: center;
        justify-content: space-between;
    }
}
</style>

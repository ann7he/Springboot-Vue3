<script setup>
import {
    Edit,
    Delete
} from '@element-plus/icons-vue'

import {ref} from 'vue'
import {studentAddService, studentDeleteService, studentListService, studentUpdateService} from "@/api/student.js";

//用户搜索时选中的专业
const major = ref('')

//用户搜索时选中的宿舍号
const dormitoryNo = ref('')

//存储dormitoryNoList里面不重复的major值
const majorList = ref([])

//存储studentList里面不重复的major值
const dormitoryNoList = ref([])
//文章列表数据模型
const students = ref([
    {
        "sno": "1357433",
        "sname": "李五",
        "major": "美术",
        "dormitoryNo": "西一402",
        "moveInDate": "2023-09-02"
    },
    {
        "sno": "123456",
        "sname": "张三",
        "major": "软件工程",
        "dormitoryNo": "西二302",
        "moveInDate": "2022-09-02"
    },
    {
        "sno": "123123",
        "sname": "陈一",
        "major": "汉语言文学",
        "dormitoryNo": "东三505",
        "moveInDate": "2023-09-02"
    },
])



//分页条数据模型
const pageNum = ref(1)//当前页
const total = ref(20)//总条数
const pageSize = ref(3)//每页条数

//当每页条数发生了变化，调用此函数
const onSizeChange = (size) => {
    pageSize.value = size
    studentList()
}
//当前页码发生变化，调用此函数
const onCurrentChange = (num) => {
    pageNum.value = num
    studentList()
}

//获取学生列表数据
const studentList = async () => {
    let params = {
        pageNum: pageNum.value,
        pageSize: pageSize.value,
        dormitoryNo: dormitoryNo.value ? dormitoryNo.value : null,
        major: major.value ? major.value : null
    }
    let result = await studentListService(params);

    // 渲染视图
    total.value = result.data.total;
    students.value = result.data.items;

    // 存储不重复的dormitoryNo值
    dormitoryNoList.value = Array.from(
            new Set(result.data.items.map((student) => student.dormitoryNo))
    );

    // 存储不重复的major值
    majorList.value = Array.from(
            new Set(result.data.items.map((student) => student.major))
    );
};

studentList();
//控制添加分类弹窗
const dialogVisible = ref(false)

//添加分类数据模型
const studentModel = ref({
    sno:'',
    sname:'',
    major:'',
    dormitoryNo:'',
    moveInDate:''
})
//添加分类表单校验
const rules = {
    sno: [
        {required: true, message: '请输入学号', trigger: 'blur'},
    ],
    sname: [
        {required: true, message: '请输入姓名', trigger: 'blur'},
    ],
    major: [
        {required: true, message: '请输入专业', trigger: 'blur'},
    ],
    dormitoryNo: [
        {required: true, message: '请输入宿舍号', trigger: 'blur'},
    ],
    moveInDate: [
        {required: true, message: '请输入入住时间', trigger: 'blur'},
    ]
}
// 调用接口，添加表单
import {ElMessage, ElMessageBox} from "element-plus";

const addStudent = async () => {
    // 调用接口
    let result = await studentAddService(studentModel.value);
    ElMessage.success(result.msg ? result.msg : '添加成功')

    // 调用获取所有文章分类的函数
    await studentList();
    dialogVisible.value = false;
}
// 定义变量，控制标题的展示
const title = ref('')

// 展示编辑弹窗
const showDialog = (row) => {
    dialogVisible.value = true;
    title.value = '编辑学生信息'
    // 数据拷贝
    studentModel.value.sno = row.sno;
    studentModel.value.sname = row.sname;
    studentModel.value.major = row.major;
    studentModel.value.dormitoryNo = row.dormitoryNo;
    studentModel.value.moveInDate = row.moveInDate;

    // 扩展id属性，将来需要传递给后台，完成分类的修改
    // studentModel.value.id = row.id
    // 设置为禁止输入
}

// 编辑分类
const updateStudent = async () => {
    // 调用接口
    let result = await studentUpdateService(studentModel.value);

    ElMessage.success(result.msg ? result.msg : '修改成功')

    // 调用获取所有分类的函数
    await studentList();
    // 隐藏弹窗
    dialogVisible.value = false;
}
// 清空模型的数据
const clearData = () => {
    studentModel.value.sno= '';
    studentModel.value.sname= '';
    studentModel.value.major= '';
    studentModel.value.dormitoryNo= '';
    studentModel.value.moveInDate= '';
}

// 删除分类
const deleteStudent = (row) => {
    ElMessageBox.confirm(
            '你确认要删除该学生信息吗',
            '温馨提示',
            {
                confirmButtonText: '确定',
                cancelButtonText: '取消',
                type: 'warning',
            }
    )
            .then(async () => {
                // 调用接口
                let result = await studentDeleteService(row.sno);
                ElMessage({
                    type: 'success',
                    message: '删除成功',
                })
                // 刷新列表
                await studentList();
            })
            .catch(() => {
                ElMessage({
                    type: 'info',
                    message: '取消删除',
                })
            })
}
</script>
<template>
    <el-card class="page-container">
        <template #header>
            <div class="header">
                <span>学生管理</span>
                <div class="extra">
                    <el-button type="primary" @click="dialogVisible=true;title='添加学生';clearData()">添加学生</el-button>
                </div>
            </div>
        </template>
        <!-- 搜索表单 -->
        <el-form inline>
            <el-form-item label="宿舍号：">
                <el-select placeholder="请选择" v-model="dormitoryNo">
                    <el-option
                            v-for="no in dormitoryNoList"
                            :key="no"
                            :label="no"
                            :value="no">
                    </el-option>
                </el-select>
            </el-form-item>

            <el-form-item label="学生专业：">
                <el-select placeholder="请选择" v-model="major">
                    <el-option
                            v-for="m in majorList"
                            :key="m"
                            :label="m"
                            :value="m">
                    </el-option>
                </el-select>
            </el-form-item>
            <el-form-item>
                <el-button type="primary" @click="studentList">搜索</el-button>
                <el-button @click="dormitoryNo='';major=''">重置</el-button>
            </el-form-item>
        </el-form>
        <!-- 学生列表 -->
        <el-table :data="students" style="width: 100%">
            <el-table-column label="学号"  prop="sno"></el-table-column>
            <el-table-column label="姓名" prop="sname"></el-table-column>
            <el-table-column label="专业" prop="major"></el-table-column>
            <el-table-column label="宿舍号" prop="dormitoryNo"></el-table-column>
            <el-table-column label="入住时间" prop="moveInDate"></el-table-column>
            <el-table-column label="操作" width="100">
                <template #default="{ row }">
                    <el-button :icon="Edit" circle plain type="primary" @click="showDialog(row)"></el-button>
                    <el-button :icon="Delete" circle plain type="danger" @click="deleteStudent(row)"></el-button>
                </template>
            </el-table-column>
            <template #empty>
                <el-empty description="没有数据"/>
            </template>
        </el-table>
        <!-- 分页条 -->
        <el-pagination v-model:current-page="pageNum" v-model:page-size="pageSize" :page-sizes="[3, 5 ,10, 15]"
                       layout="jumper, total, sizes, prev, pager, next" background :total="total"
                       @size-change="onSizeChange"
                       @current-change="onCurrentChange" style="margin-top: 20px; justify-content: flex-end"/>

        <!--        添加分类弹窗-->
        <el-dialog v-model="dialogVisible" :title="title" width="30%">
            <el-form :model="studentModel" :rules="rules" label-width="100px" style="padding-right: 30px">
                <el-form-item label="学号" prop="sno">
                    <el-input v-model="studentModel.sno" minlength="1"  maxlength="10"></el-input>
                </el-form-item>
                <el-form-item label="姓名" prop="sname">
                    <el-input v-model="studentModel.sname" minlength="1" maxlength="15"></el-input>
                </el-form-item>
                <el-form-item label="专业" prop="major">
                    <el-input v-model="studentModel.major" minlength="1" maxlength="15"></el-input>
                </el-form-item>
                <el-form-item label="宿舍号" prop="dormitoryNo">
                    <el-input v-model="studentModel.dormitoryNo" minlength="1" maxlength="15"></el-input>
                </el-form-item>
                <el-form-item label="入住时间" prop="moveInDate">
                    <el-date-picker
                            type="date"
                            placeholder="选择日期"
                            v-model="studentModel.moveInDate"
                    />
                </el-form-item>
            </el-form>
            <template #footer>
        <span class="dialog-footer">
            <el-button @click="dialogVisible = false">取消</el-button>
            <el-button type="primary" @click="title==='添加学生'?addStudent():updateStudent()"> 确认 </el-button>
        </span>
            </template>
        </el-dialog>
    </el-card>
</template>
<style lang="scss" scoped>
.page-container {
    min-height: 100%;
    box-sizing: border-box;

    .header {
        display: flex;
        align-items: center;
        justify-content: space-between;
    }
}
</style>
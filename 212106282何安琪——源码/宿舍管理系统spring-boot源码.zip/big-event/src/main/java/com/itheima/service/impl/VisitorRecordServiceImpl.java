package com.itheima.service.impl;

import com.itheima.mapper.VisitorRecordMapper;
import com.itheima.pojo.VistorRecord;
import com.itheima.service.VisitorRecordService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class VisitorRecordServiceImpl implements VisitorRecordService {
    @Autowired
    private VisitorRecordMapper visitorRecordMapper;

    @Override
    public void add(VistorRecord vistorRecord) {
        vistorRecord.setVisitTime(LocalDateTime.now());
        visitorRecordMapper.add(vistorRecord);
    }

    @Override
    public VistorRecord findById(String sno) {
        VistorRecord v = visitorRecordMapper.findById(sno);
        return v;
    }

    @Override
    public void delete(String recordId) {
         visitorRecordMapper.delete(recordId);
    }

    @Override
    public List<VistorRecord> list(String sno) {
        return visitorRecordMapper.list(sno);
    }
}

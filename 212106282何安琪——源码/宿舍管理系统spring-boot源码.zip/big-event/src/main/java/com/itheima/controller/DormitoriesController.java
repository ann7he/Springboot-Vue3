package com.itheima.controller;

import com.itheima.pojo.Article;
import com.itheima.pojo.Dormitories;
import com.itheima.pojo.PageBean;
import com.itheima.pojo.Result;
import com.itheima.service.DormitoriesService;
import org.apache.ibatis.annotations.Insert;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/dormitories")
public class DormitoriesController {
    @Autowired
    private DormitoriesService dormitoriesService;

    @PostMapping
    public Result add(@RequestBody @Validated(Dormitories.Add.class) Dormitories dormitories) {
        dormitoriesService.add(dormitories);
        return Result.success();
    }

    @GetMapping
    public Result<PageBean<Dormitories>> list(
            Integer pageNum,
            Integer pageSize,
            @RequestParam(required = false) String dormitoryNo,
            @RequestParam(required = false) String dormitoryName,
            @RequestParam(required = false) String administrator,
            @RequestParam(required = false) String status
    ) {

        PageBean<Dormitories> pb = dormitoriesService.list(pageNum, pageSize, dormitoryNo, dormitoryName, administrator, status);
        return Result.success(pb);
    }
    @GetMapping("/detail")
    public Result<Dormitories> detail(String dormitoryNo){
        Dormitories d = dormitoriesService.findByNo(dormitoryNo);
        return Result.success(d);
    }
    @PutMapping
    public Result update(@RequestBody @Validated(Dormitories.Update.class) Dormitories dormitories){
        dormitoriesService.update(dormitories);
        return Result.success();
    }
    @DeleteMapping
    public Result delete(@RequestParam("dormitoryNo") String dormitoryNo){
        dormitoriesService.delete(dormitoryNo);
        return Result.success();
    }
}

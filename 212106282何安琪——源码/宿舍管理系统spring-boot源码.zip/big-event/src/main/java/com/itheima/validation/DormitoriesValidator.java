package com.itheima.validation;

import com.itheima.anno.DormitoriesStatus;
import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

public class DormitoriesValidator implements ConstraintValidator<DormitoriesStatus, String> {
    @Override
    public boolean isValid(String value, ConstraintValidatorContext constraintValidatorContext) {
        if (value == null) {
            // 允许为空值
            return true;
        } else {
            // 只允许使用中或空宿舍的状态
            return "使用中".equals(value) || "空宿舍".equals(value);
        }
    }
}

package com.itheima.pojo;

import com.itheima.anno.DormitoriesStatus;
import com.itheima.anno.State;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.groups.Default;
import lombok.Data;

@Data
public class Dormitories {
// 宿舍号
    @NotNull(groups = {Dormitories.Update.class})
    private String dormitoryNo;
// 宿舍楼名
    private String dormitoryName;
// 人数
    @Min(value = 0, message = "人数至少为0")
    @Max(value = 4, message = "人数不得超过4人")
    private int occupancy;
// 管理员
    @NotEmpty
    private String administrator;
// 使用状态
    @DormitoriesStatus
    private String status;//使用状态 使用中|空宿舍

    public interface Add extends Default {
    }

    public interface Update extends Default {
    }
}

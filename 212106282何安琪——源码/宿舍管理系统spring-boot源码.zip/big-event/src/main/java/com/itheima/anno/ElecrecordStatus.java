package com.itheima.anno;

import com.itheima.validation.ElecrecordStatusValidation;
import jakarta.validation.Constraint;
import jakarta.validation.Payload;

import java.lang.annotation.*;

@Documented//元注解
@Target({ElementType.FIELD})
@Retention(RetentionPolicy.RUNTIME)//元注解
@Constraint(
        validatedBy = {ElecrecordStatusValidation.class}//指定提供校验规则的类
)
public @interface ElecrecordStatus {
    //提供校验失败后的信息
    String message() default "status参数的值只能是未缴费或者已缴费";

    //指定分组
    Class<?>[] groups() default {};

    //负载  获取到State注解的附加信息
    Class<? extends Payload>[] payload() default {};
}

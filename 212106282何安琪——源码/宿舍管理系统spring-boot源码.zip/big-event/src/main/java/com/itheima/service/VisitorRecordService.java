package com.itheima.service;

import com.itheima.pojo.VistorRecord;

import java.util.List;

public interface VisitorRecordService {
    //新增访客记录
    void add(VistorRecord vistorRecord);
    //查询访客详情
    VistorRecord findById(String sno);
    //删除
    void delete(String recordId);
    //列表查询
    List<VistorRecord> list(String sno);
}

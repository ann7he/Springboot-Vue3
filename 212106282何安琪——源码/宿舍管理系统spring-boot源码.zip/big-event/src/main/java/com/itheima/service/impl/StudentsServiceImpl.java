package com.itheima.service.impl;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.itheima.mapper.StudentsMapper;
import com.itheima.pojo.PageBean;
import com.itheima.pojo.Students;
import com.itheima.service.StudentsService;
import com.itheima.utils.ThreadLocalUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
@Service
public class StudentsServiceImpl implements StudentsService {
    @Autowired
    private StudentsMapper studentsMapper;

    @Override
    public void add(Students students) {
        // Map<String,Object> map = ThreadLocalUtil.get();
        // String sno = (String) map.get("sno");
        // students.setSno(sno);
        studentsMapper.add(students);
    }

    @Override
    public PageBean<Students> list(Integer pageNum, Integer pageSize, String dormitoryNo, String major) {
        // 创建PageBean对象
        PageBean<Students> pb = new PageBean<>();
        //启动分页插件
        PageHelper.startPage(pageNum, pageSize);
        // 调用Mapper
        List<Students> ss = studentsMapper.list(dormitoryNo,major);
        // Page中提供了方法，可以获取PageHelper分页查询后得的总记录条数和和当前页数据
        Page<Students> p = (Page<Students>) ss;
        // 把数据填充到PageBean对象中
        pb.setTotal(p.getTotal());
        pb.setItems(p.getResult());
        return pb;
    }

    @Override
    public Students findBySno(String sno) {
        Students s = studentsMapper.findBySno(sno);
        return s;
    }

    @Override
    public void update(Students students) {
        studentsMapper.update(students);
    }

    @Override
    public void delete(String sno) {
        studentsMapper.delete(sno);
    }


}

package com.itheima.controller;

import com.itheima.pojo.Result;
import com.itheima.pojo.VistorRecord;
import com.itheima.service.VisitorRecordService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/visitorrecord")
public class VisitorRecordController {
    @Autowired
    private VisitorRecordService visitorRecordService;
    @PostMapping
    public Result add(@RequestBody @Validated(VistorRecord.Add.class) VistorRecord vistorRecord){
        visitorRecordService.add(vistorRecord);
        return Result.success();
    }
    @GetMapping("/detail")
    public Result<VistorRecord> detail(String sno){
        VistorRecord v = visitorRecordService.findById(sno);
        return Result.success(v);
    }

    @DeleteMapping
    public Result delete(@RequestParam("recordId") String recordId){
        visitorRecordService.delete(recordId);
        return Result.success();
    }

    @GetMapping("/search")
    public Result<List<VistorRecord>> list(String sno){
        List<VistorRecord> vr = visitorRecordService.list(sno);
        return Result.success(vr);
    }

}

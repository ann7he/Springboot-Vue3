package com.itheima.pojo;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.groups.Default;
import lombok.Data;

import java.time.LocalDateTime;
@Data
//访客信息表
public class VistorRecord {
    //记录号
    @NotNull(groups = {Article.Update.class})
    public String recordId;
    //学号
    public String sno;
    //访客姓名
    public String visitorName;
    //访客时间
    public LocalDateTime visitTime;
    // 联系方式？
    public interface Add extends Default {

    }
    public interface Update extends Default {

    }
}

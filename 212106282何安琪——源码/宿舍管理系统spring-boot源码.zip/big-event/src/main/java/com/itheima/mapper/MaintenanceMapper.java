package com.itheima.mapper;

import com.itheima.pojo.Maintenance;
import org.apache.ibatis.annotations.*;

import java.util.List;

@Mapper
public interface MaintenanceMapper {
    //新增
    @Insert("insert into maintenance(mainten_id,dormitory_no,property_no,reason,mainten_time)" +
            "values (#{maintenId},#{dormitoryNo},#{propertyNo},#{reason},#{maintenTime})")
    void add(Maintenance maintenance);
    //条件分页
    List<Maintenance> list(String dormitoryNo, String status);
    //查询详细信息
    @Select("select * from maintenance where mainten_id=#{maintenId}")
    Maintenance findById(String maintenId);
    //更新状态信息
    @Update("update maintenance set status=#{status} where mainten_id=#{maintenId}")
    void update(Maintenance maintenance);
    //删除报修信息
    @Delete("delete from maintenance where mainten_id=#{maintenId}")
    void delete(String maintenId);
}

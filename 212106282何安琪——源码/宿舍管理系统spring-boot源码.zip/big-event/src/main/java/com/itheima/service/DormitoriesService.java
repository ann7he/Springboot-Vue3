package com.itheima.service;

import com.itheima.pojo.Dormitories;
import com.itheima.pojo.PageBean;

public interface DormitoriesService {
    //新增宿舍
    void add(Dormitories dormitories);
    //宿舍列表（条件分页）
    PageBean<Dormitories> list(Integer pageNum, Integer pageSize,String dormitoryNo ,String dormitoryName, String administrator, String status);
    //获取宿舍信息
    Dormitories findByNo(String dormitoryNo);
    //更新宿舍信息
    void update(Dormitories dormitories);
    //删除
    void delete(String dormitoryNo);
}

package com.itheima.mapper;

import com.itheima.pojo.Dormitories;
import org.apache.ibatis.annotations.*;

import java.util.List;

@Mapper
public interface DormitoriesMapper {
    //新增
    @Insert("insert into dormitories(dormitory_no,dormitory_name,occupancy,administrator,status)" +
            "values (#{dormitoryNo},#{dormitoryName},#{occupancy},#{administrator},#{status})")
    void add(Dormitories dormitories);
    //宿舍列表(条件分页)
    List<Dormitories> list(String dormitoryNo,String dormitoryName, String administrator, String status);
    //获取宿舍信息
    @Select("select  * from dormitories where dormitory_no=#{dormitoryNo}")
    Dormitories findByNo(String dormitoryNo);
    //更新
    @Update("update dormitories set occupancy=#{occupancy},administrator=#{administrator},status=#{status} where dormitory_no=#{dormitoryNo}")
    void update(Dormitories dormitories);
    //删除
    @Delete("delete from dormitories where dormitory_no=#{dormitoryNo}")
    void delete(String dormitoryNo);

}

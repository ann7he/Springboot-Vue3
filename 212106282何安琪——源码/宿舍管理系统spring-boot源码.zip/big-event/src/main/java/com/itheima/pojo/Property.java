package com.itheima.pojo;

import com.itheima.anno.PropertyStatus;
import com.itheima.anno.State;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.groups.Default;
import lombok.Data;

import java.time.LocalDate;
@Data
//宿舍财产表
public class Property {
    // 财产号
    @NotNull(groups = {Property.Update.class})
    private String propertyNo;
    //宿舍号
    @NotEmpty
    private String dormitoryNo;
    //财产名
    private String propertyName;
    //购买日期
    private LocalDate purchaseDate;
    @PropertyStatus
    //财产状态  保修中...  /  使用中...
    private String status;
    public interface Add extends Default {

    }
    public interface Update extends Default {

    }
}

package com.itheima.mapper;

import com.itheima.pojo.Students;
import org.apache.ibatis.annotations.*;

import java.util.List;

@Mapper
public interface StudentsMapper {


    //新增
    @Insert("insert into students(sno,sname,major,dormitory_no,move_in_date)" +
            "values (#{sno},#{sname},#{major},#{dormitoryNo},#{moveInDate})")
    void add(Students students);
    //学生列表（条件分页）
    List<Students> list(String dormitoryNo, String major);
    //获取学生详情
    @Select("select * from students where sno=#{sno}")
    Students findBySno(String sno);
    //更新
    @Update("update students set major=#{major},dormitory_no=#{dormitoryNo},move_in_date=#{moveInDate} where sno=#{sno}")
    void update(Students students);
    //删除
    @Delete("delete from students where sno=#{sno}")
    void delete(String sno);
    //删除
}

package com.itheima.service.impl;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.itheima.mapper.DormitoriesMapper;
import com.itheima.pojo.Article;
import com.itheima.pojo.Dormitories;
import com.itheima.pojo.PageBean;
import com.itheima.service.DormitoriesService;
import com.itheima.utils.ThreadLocalUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public class DormitoriesServiceImpl implements DormitoriesService {
    @Autowired
    private DormitoriesMapper dormitoriesMapper;
    @Override
    public void add(Dormitories dormitories) {
        dormitoriesMapper.add(dormitories);
    }

    @Override
    public PageBean<Dormitories> list(Integer pageNum, Integer pageSize,String dormitoryNo, String dormitoryName, String administrator, String status) {
        //1、创建PageBean对象
        PageBean<Dormitories> pb = new PageBean<>();
        //2、启动分页插件 PageHelper
        PageHelper.startPage(pageNum, pageSize);
        // 3、调用Mapper
        // Map<String,Object> map = ThreadLocalUtil.get();
        // String userId1 = (String) map.get("id");
        // int userId = Integer.parseInt(userId1);
        List<Dormitories> ds = dormitoriesMapper.list(dormitoryNo,dormitoryName,administrator,status);
        // Page中提供了方法，可以获取PageHelper分页查询后得的总记录条数和和当前页数据
        Page<Dormitories> p = (Page<Dormitories>) ds;
        // 把数据填充到PageBean对象中
        pb.setTotal(p.getTotal());
        pb.setItems(p.getResult());
        return pb;
    }

    @Override
    public Dormitories findByNo(String dormitoryNo) {
        Dormitories d = dormitoriesMapper.findByNo(dormitoryNo);
        return d;
    }

    @Override
    public void update(Dormitories dormitories) {
        dormitoriesMapper.update(dormitories);
    }

    @Override
    public void delete(String dormitoryNo) {
        dormitoriesMapper.delete(dormitoryNo);
    }
}

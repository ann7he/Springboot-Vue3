package com.itheima.service;
import com.itheima.pojo.Maintenance;
import com.itheima.pojo.PageBean;

public interface MaintenanceService {
    //新增报修
    void add(Maintenance maintenance);
    //条件分页列表
    PageBean<Maintenance> list(Integer pageNum, Integer pageSize, String dormitoryNo, String status);
    //查询详细信息
    Maintenance findById(String maintenId);
    //更新报修状态
    void update(Maintenance maintenance);
    //删除
    void delete(String id);
}

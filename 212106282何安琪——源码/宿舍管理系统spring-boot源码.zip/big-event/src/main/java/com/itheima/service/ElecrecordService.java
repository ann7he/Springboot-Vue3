package com.itheima.service;

import com.itheima.pojo.ElecRecord;
import com.itheima.pojo.PageBean;

public interface ElecrecordService {
    //新增电费记录
    void add(ElecRecord elecRecord);
    //通过宿舍号查询电费详情
    ElecRecord findByNo(String dormitoryNo);
    //更新
    void update(ElecRecord elecRecord);
    //删除
    void delete(String recordId);
    //条件分页查询
    PageBean<ElecRecord> list(Integer pageNum, Integer pageSize, String dormitoryNo, String status);
}

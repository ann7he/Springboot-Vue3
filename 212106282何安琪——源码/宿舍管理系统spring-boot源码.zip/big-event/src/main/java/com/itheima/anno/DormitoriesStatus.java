package com.itheima.anno;

import com.itheima.validation.DormitoriesValidator;
import jakarta.validation.Constraint;
import jakarta.validation.Payload;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;


@Target({ ElementType.FIELD, ElementType.METHOD })
@Retention(RetentionPolicy.RUNTIME)
@Constraint(validatedBy = DormitoriesValidator.class)
public @interface DormitoriesStatus{
    String message() default "宿舍状态只能为：使用中或空宿舍";

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};
}

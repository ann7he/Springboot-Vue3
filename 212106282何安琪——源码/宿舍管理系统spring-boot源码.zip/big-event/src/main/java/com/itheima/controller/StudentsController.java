package com.itheima.controller;

import com.itheima.pojo.PageBean;
import com.itheima.pojo.Result;
import com.itheima.pojo.Students;
import com.itheima.service.StudentsService;
import org.assertj.core.error.ShouldHaveNext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/students")
public class StudentsController {
    @Autowired
    private StudentsService studentsService;
    @PostMapping
    public Result add (@RequestBody Students students){
        studentsService.add(students);
        return Result.success();
    }
    @GetMapping
    public  Result<PageBean<Students>> list(
            Integer pageNum,
            Integer pageSize,
            @RequestParam(required = false) String dormitoryNo,
            @RequestParam(required = false) String major
    ){
        PageBean<Students> pb = studentsService.list(pageNum,pageSize,dormitoryNo,major);
        return Result.success(pb);
    }
    @GetMapping("/detail")
    public Result<Students> detail(String sno){
        Students s = studentsService.findBySno(sno);
        return Result.success(s);
    }
    @PutMapping
    public Result update(@RequestBody @Validated(Students.Update.class) Students students){
        studentsService.update(students);
        return Result.success();
    }
    @DeleteMapping
    public Result delete(@RequestParam("sno") String sno){
        studentsService.delete(sno);
        return Result.success();
    }
}

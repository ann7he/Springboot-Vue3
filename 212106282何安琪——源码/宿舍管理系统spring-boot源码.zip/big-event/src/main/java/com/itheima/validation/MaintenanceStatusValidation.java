package com.itheima.validation;

import com.itheima.anno.ElecrecordStatus;
import com.itheima.anno.MaintenanceStatus;
import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

public class MaintenanceStatusValidation implements ConstraintValidator<MaintenanceStatus, String> {
    @Override
    public boolean isValid(String s, ConstraintValidatorContext constraintValidatorContext) {
        if (s == null) {
            // 允许为空值
            return true;
        } else {
            // 只允许报修中或已报修的状态
            return "报修中".equals(s) || "已报修".equals(s);
        }
    }
}

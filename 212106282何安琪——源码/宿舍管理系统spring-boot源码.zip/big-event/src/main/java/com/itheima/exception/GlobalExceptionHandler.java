package com.itheima.exception;

import com.itheima.pojo.Result;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class GlobalExceptionHandler {
    //全局
    @ExceptionHandler(Exception.class)
    public Result handException(Exception e) {
        e.printStackTrace();
        return Result.error(!e.getMessage().isEmpty() ? e.getMessage() : "操作失败");
    }
}

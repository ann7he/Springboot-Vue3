package com.itheima.validation;

import com.itheima.anno.PropertyStatus;
import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;


public class PropertyStatusValidator implements ConstraintValidator<PropertyStatus, String> {

    @Override
    public void initialize(PropertyStatus constraintAnnotation) {
        // 这里可以做一些初始化操作，比如读取配置等。
    }

    @Override
    public boolean isValid(String value, ConstraintValidatorContext context) {
        if (value == null) {
            // 允许为空值
            return true;
        } else {
            // 只允许使用中或报修中的状态
            return "使用中".equals(value) || "报修中".equals(value);
        }
    }

}

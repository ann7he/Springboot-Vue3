package com.itheima.mapper;

import com.itheima.pojo.Property;
import org.apache.ibatis.annotations.*;

import java.util.List;

@Mapper
public interface PropertyMapper {


    //新增
    @Insert("insert into property(property_no,dormitory_no,property_name,purchase_date,status)" +
            "values (#{propertyNo},#{dormitoryNo},#{propertyName},#{purchaseDate},#{status})")
    void add(Property property);

    //财产列表（条件分页）
    List<Property> list(String dormitoryNo, String propertyName, String status);
    //查询
    @Select("select * from property where property_no=#{propertyNo}")
    Property findByNo(String propertyNo);
    //更新
    @Update("update property set dormitory_no=#{dormitoryNo},status =#{status} where property_no=#{propertyNo};")
    void update(Property property);
    //删除
    @Delete("delete from property where property_no=#{propertyNo}")
    void delete(String propertyNo);


}

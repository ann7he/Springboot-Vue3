package com.itheima.service.impl;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.itheima.mapper.ElecrecordMapper;
import com.itheima.pojo.ElecRecord;
import com.itheima.pojo.Maintenance;
import com.itheima.pojo.PageBean;
import com.itheima.service.ElecrecordService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

@Service
public class ElecrecordServiceImpl implements ElecrecordService {
    @Autowired
    private ElecrecordMapper elecrecordMapper;
    @Override
    public void add(ElecRecord elecRecord) {
        elecRecord.setDate(LocalDate.now());
        elecrecordMapper.add(elecRecord);
    }

    @Override
    public ElecRecord findByNo(String dormitoryNo) {
        ElecRecord e = elecrecordMapper.findByNo(dormitoryNo);
        return e;
    }

    @Override
    public void update(ElecRecord elecRecord) {
        elecrecordMapper.update(elecRecord);
    }

    @Override
    public void delete(String recordId) {
        elecrecordMapper.delete(recordId);
    }

    @Override
    public PageBean<ElecRecord> list(Integer pageNum, Integer pageSize, String dormitoryNo, String status) {
        //1、创建PageBean对象
        PageBean<ElecRecord> pb = new PageBean<>();
        //2、启动分页插件 PageHelpe
        PageHelper.startPage(pageNum, pageSize);
        // 3、调用Mapper
        List<ElecRecord> er = elecrecordMapper.list(dormitoryNo,status);
        // Page中提供了方法，可以获取PageHelper分页查询后得的总记录条数和和当前页数据
        Page<ElecRecord> p = (Page<ElecRecord>) er;
        // 把数据填充到PageBean对象中
        pb.setTotal(p.getTotal());
        pb.setItems(p.getResult());
        return pb;
    }
}

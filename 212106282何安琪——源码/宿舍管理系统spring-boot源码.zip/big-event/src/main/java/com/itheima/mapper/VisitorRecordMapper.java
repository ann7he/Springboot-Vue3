package com.itheima.mapper;

import com.itheima.pojo.VistorRecord;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface VisitorRecordMapper {
    //新增
    @Insert("insert into visitorrecord(record_id,sno,visitor_name,visit_time)" +
            "values (#{recordId},#{sno},#{visitorName},#{visitTime})")
    void add(VistorRecord vistorRecord);
    //查询
    @Select("select * from visitorrecord where sno=#{sno}")
    VistorRecord findById(String recordId);
    //删除
    @Delete("delete from visitorrecord where record_id=#{recordId}")
    void delete(String recordId);
    //查询被访问者的所有记录
    @Select("select * from visitorrecord where sno = #{sno}")
    List<VistorRecord> list(String sno);
}

package com.itheima.validation;

import com.itheima.anno.DormitoriesStatus;
import com.itheima.anno.ElecrecordStatus;
import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

public class ElecrecordStatusValidation implements ConstraintValidator<ElecrecordStatus, String> {
    @Override
    public boolean isValid(String s, ConstraintValidatorContext constraintValidatorContext) {
        if (s == null) {
            // 允许为空值
            return true;
        } else {
            // 只允许已缴费或未缴费的状态
            return "已缴费".equals(s) || "未缴费".equals(s);
        }
    }
}

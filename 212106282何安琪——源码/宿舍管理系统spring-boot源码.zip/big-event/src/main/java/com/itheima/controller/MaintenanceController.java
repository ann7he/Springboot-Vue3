package com.itheima.controller;

import com.itheima.pojo.Article;
import com.itheima.pojo.Maintenance;
import com.itheima.pojo.PageBean;
import com.itheima.pojo.Result;
import com.itheima.service.MaintenanceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/maintenance")
public class MaintenanceController {
    @Autowired
    private MaintenanceService maintenanceService;
    @PostMapping
    public Result add(@RequestBody @Validated(Maintenance.Add.class) Maintenance maintenance){
        maintenanceService.add(maintenance);
        return Result.success();
    }
    @GetMapping
    public Result<PageBean<Maintenance>> list(
            Integer pageNum,
            Integer pageSize,
            @RequestParam(required = false) String dormitoryNo,
            @RequestParam(required = false) String status
    ){
        PageBean<Maintenance> pb = maintenanceService.list(pageNum, pageSize, dormitoryNo, status);
        return Result.success(pb);
    }
    @GetMapping("/detail")
    public Result<Maintenance> detail(String maintenId){
        Maintenance a = maintenanceService.findById(maintenId);
        return Result.success(a);
    }
    @PutMapping
    public Result update(@RequestBody @Validated(Maintenance.Update.class) Maintenance maintenance){
        maintenanceService.update(maintenance);
        return Result.success();
    }
    @DeleteMapping
    public Result delete(@RequestParam("maintenId") String maintenId){
        maintenanceService.delete(maintenId);
        return Result.success();
    }
}

package com.itheima.service;

import com.itheima.pojo.PageBean;
import com.itheima.pojo.Students;


public interface StudentsService {
    //添加学生
    void add(Students students);
    //学生列表（条件分页）
    PageBean<Students> list(Integer pageNum, Integer pageSize, String dormitoryNo, String major);
    //获取学生详细信息
    Students findBySno(String sno);
    //更新
    void update(Students students);
    //删除
    void delete(String sno);
}

package com.itheima.mapper;

import com.itheima.pojo.ElecRecord;
import org.apache.ibatis.annotations.*;

import java.util.List;

@Mapper
public interface ElecrecordMapper {
    //新增
    @Insert("insert into elecrecord(record_id,date,dormitory_no,consumption,cost,status) " +
            "values (#{recordId},#{date},#{dormitoryNo},#{consumption},#{cost},#{status})")

    void add(ElecRecord elecRecord);
    //获取宿舍电费记录
    @Select("select * from elecrecord where dormitory_no=#{dormitoryNo}")
    ElecRecord findByNo(String dormitoryNo);
    //更新
    @Update("update elecrecord set status=#{status} where record_id=#{recordId}")
    void update(ElecRecord elecRecord);
    //删除
    @Delete("delete from elecrecord where record_id=#{recordId}")
    void delete(String recordId);
    //条件分页列表
    List<ElecRecord> list(String dormitoryNo, String status);
}

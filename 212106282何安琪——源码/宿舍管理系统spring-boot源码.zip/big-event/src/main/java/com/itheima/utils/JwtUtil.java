package com.itheima.utils;

import com.auth0.jwt.JWT;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.interfaces.Claim;
import com.auth0.jwt.interfaces.DecodedJWT;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class JwtUtil {

    private static final String KEY = "itheima";

    //接收业务数据,生成token并返回
    public static String genToken(Map<String, Object> claims) {
        System.out.println(String.valueOf(claims));
        Object id = claims.get("id");
        System.out.println(id);
        return JWT.create()
                .withClaim("id", claims.get("id").toString())
                .withClaim("username", claims.get("username").toString())
                .withClaim("role", claims.get("role").toString())
                .withExpiresAt(new Date(System.currentTimeMillis() + 1000 * 60 * 60))
                .sign(Algorithm.HMAC256(KEY));
    }

    //接收token,验证token,并返回业务数据
    public static Map<String, Object> parseToken(String token) {
        //     System.out.println(token);
        //     return JWT.require(Algorithm.HMAC256(KEY))
        //             .build()
        //             .verify(token)
        //             .getClaim("claims")
        //             .asMap();
        // }

        // 验证 JWT 令牌并返回 DecodedJWT 对象
        DecodedJWT decodedJWT = JWT.require(Algorithm.HMAC256(KEY)).build().verify(token);

// 获取声明信息
        Map<String, Claim> claims = decodedJWT.getClaims();

// 将 Claim 对象转换为对应的值类型，并存储到 Map 中
        Map<String, Object> map = new HashMap<>();
        for (Map.Entry<String, Claim> entry : claims.entrySet()) {
            String key = entry.getKey();
            Claim claim = entry.getValue();
            if (claim.isNull()) {
                map.put(key, null);
            } else if (claim.asBoolean() != null) {
                map.put(key, claim.asBoolean());
            } else if (claim.asLong() != null) {
                map.put(key, claim.asLong());
            } else if (claim.asDouble() != null) {
                map.put(key, claim.asDouble());
            } else if (claim.asDate() != null) {
                map.put(key, claim.asDate());
            } else {
                map.put(key, claim.asString());
            }
        }
        return map;
    }
}

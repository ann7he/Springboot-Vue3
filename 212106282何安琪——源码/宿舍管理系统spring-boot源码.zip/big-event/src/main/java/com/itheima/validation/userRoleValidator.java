package com.itheima.validation;

import com.itheima.anno.State;
import com.itheima.anno.UserRoleStatus;
import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

public class userRoleValidator implements ConstraintValidator<UserRoleStatus, String> {
    @Override
    public boolean isValid(String s, ConstraintValidatorContext constraintValidatorContext) {
        //提供校验规则
        if (s == null) {
            return false;
        }
        if (s.equals("admin")||s.equals("engineer")||s.equals("student")||s.equals("未知")){
            return true;
        }
        return false;
    }
}

package com.itheima.pojo;

import com.itheima.anno.ElecrecordStatus;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.groups.Default;
import lombok.Data;

import java.time.LocalDate;

@Data
public class ElecRecord {
    @NotNull(groups = {Article.Update.class})
    //记录号
    private String recordId;
    //宿舍号
    private String dormitoryNo;
    //所缴年月份日期
    private LocalDate date;
    //用电量
    private String consumption;
    //消费
    private String cost;
    //是否缴费  版本吧
    @ElecrecordStatus
    private String status;
    public interface Add extends Default {

    }
    public interface Update extends Default {

    }
}

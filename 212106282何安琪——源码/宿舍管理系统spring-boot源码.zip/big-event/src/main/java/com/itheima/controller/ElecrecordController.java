package com.itheima.controller;

import com.itheima.pojo.ElecRecord;
import com.itheima.pojo.Maintenance;
import com.itheima.pojo.PageBean;
import com.itheima.pojo.Result;
import com.itheima.service.ElecrecordService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/elecrecord")
public class ElecrecordController {
    @Autowired
    private ElecrecordService elecrecordService;

    @PostMapping
    public Result add(@RequestBody @Validated(ElecRecord.Add.class) ElecRecord elecRecord) {
        elecrecordService.add(elecRecord);
        return Result.success();
    }

    @GetMapping
    public Result<PageBean<ElecRecord>> list(
            Integer pageNum,
            Integer pageSize,
            @RequestParam(required = false) String dormitoryNo,
            @RequestParam(required = false) String status
    ) {
        PageBean<ElecRecord> pb = elecrecordService.list(pageNum, pageSize, dormitoryNo, status);
        return Result.success(pb);
    }

    @GetMapping("/detail")
    public Result<ElecRecord> detail(String dormitoryNo) {
        ElecRecord e = elecrecordService.findByNo(dormitoryNo);
        return Result.success(e);
    }

    @PutMapping
    public Result update(@RequestBody @Validated(ElecRecord.Update.class) ElecRecord elecRecord) {
        elecrecordService.update(elecRecord);
        return Result.success();
    }

    @DeleteMapping
    public Result delete(@RequestParam("recordId") String recordId) {
        elecrecordService.delete(recordId);
        return Result.success();
    }
}

package com.itheima.service;

import com.itheima.pojo.PageBean;
import com.itheima.pojo.Property;

public interface PropertyService {
    //新增财产
    void add(Property property);
    //财产列表(条件分页)
    PageBean<Property> list(Integer pageNum, Integer pageSize, String dormitoryNo, String propertyName, String status);
    //获取财产详情
    Property findByNo(String propertyNo);
    //更新财产
    void update(Property property);
    //删除
    void delete(String propertyNo);
}

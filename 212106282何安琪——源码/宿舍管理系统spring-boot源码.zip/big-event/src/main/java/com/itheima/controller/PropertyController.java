package com.itheima.controller;

import com.itheima.pojo.Article;
import com.itheima.pojo.PageBean;
import com.itheima.pojo.Property;
import com.itheima.pojo.Result;
import com.itheima.service.PropertyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/property")
public class PropertyController {
    @Autowired
    private PropertyService propertyService;
    @PostMapping
    public Result add(@RequestBody @Validated(Property.Add.class) Property property){
        propertyService.add(property);
        return Result.success();
    }
    @GetMapping
    public Result<PageBean<Property>> list(
            Integer pageNum,
            Integer pageSize,
            @RequestParam(required = false) String dormitoryNo,
            @RequestParam(required = false) String propertyName,
            @RequestParam(required = false) String status
    ){
        PageBean<Property> pb = propertyService.list(pageNum, pageSize, dormitoryNo, propertyName,status);
        return Result.success(pb);
    }
    @GetMapping("/detail")
    public Result<Property> detail(String propertyNo){
        Property p = propertyService.findByNo(propertyNo);
        return Result.success(p);
    }
    @PutMapping
    public Result update(@RequestBody @Validated(Property.Update.class) Property property){
        propertyService.update(property);
        return Result.success();
    }
    @DeleteMapping
    public Result delete(@RequestParam("propertyNo")String propertyNo){
        propertyService.delete(propertyNo);
        return Result.success();
    }
}

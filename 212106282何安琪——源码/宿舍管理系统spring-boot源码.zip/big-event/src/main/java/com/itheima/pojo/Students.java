package com.itheima.pojo;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.groups.Default;
import lombok.Data;
import net.bytebuddy.pool.TypePool;

import java.text.DecimalFormat;
import java.time.LocalDate;

//宿舍学生信息表
@Data
public class Students {
    @NotNull(groups = {Students.Update.class})
    //学号
    private String sno;
    //姓名
    @NotEmpty
    private String sname;
    //专业
    @NotEmpty
    private String major;
    //宿舍号
    @NotEmpty
    private String dormitoryNo;
    //入住时间
    private LocalDate moveInDate;

    public void update(Students students) {
    }

    public interface Update extends Default {
    }
}

package com.itheima.pojo;

import com.itheima.anno.MaintenanceStatus;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.groups.Default;
import lombok.Data;

import java.time.LocalDateTime;
@Data
//保修单
public class Maintenance {
    @NotNull(groups = {Maintenance.Update.class})
    //维修号
    private String  maintenId;
    //宿舍号
    private String dormitoryNo;
    //财产号
    private String propertyNo;
    //记录维修时间
    private LocalDateTime maintenTime;
    //损坏原因
    private String reason;
    @MaintenanceStatus
    private String status;//维修状态  报修中|已报修
    public interface Add extends Default {

    }
    public interface Update extends Default {

    }
}

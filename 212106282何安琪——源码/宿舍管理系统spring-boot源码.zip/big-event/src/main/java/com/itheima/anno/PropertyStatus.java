package com.itheima.anno;

import com.itheima.validation.PropertyStatusValidator;
import jakarta.validation.Constraint;
import jakarta.validation.Payload;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target({ ElementType.FIELD, ElementType.METHOD })
@Retention(RetentionPolicy.RUNTIME)
@Constraint(validatedBy = PropertyStatusValidator.class)
public @interface PropertyStatus {

    String message() default "财产状态只能为：使用中或报修中";

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};
}
